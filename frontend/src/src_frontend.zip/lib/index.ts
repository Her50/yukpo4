// src/core/index.ts (ou similaire)

export * as accessClient from './accessClient';
export * as IAProductRegistry from './IAProductRegistry';
export * as notifications from './notifications';
export * as utils from './utils';
export * as accessregistry from './accessregistry';
