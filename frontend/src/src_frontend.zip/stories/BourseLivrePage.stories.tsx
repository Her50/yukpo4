import React from "react";

const BourseLivrePageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>BourseLivrePage Stories</h2>
    </div>
  );
};

export default BourseLivrePageStories;
