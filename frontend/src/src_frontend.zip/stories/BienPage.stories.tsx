import React from "react";

const BienPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>BienPage Stories</h2>
    </div>
  );
};

export default BienPageStories;
