import React from "react";

const StrategicRecoPanelStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>StrategicRecoPanel.stories</h2>
    </div>
  );
};

export default StrategicRecoPanelStories;
