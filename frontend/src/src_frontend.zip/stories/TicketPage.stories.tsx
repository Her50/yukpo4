import React from "react";

const TicketPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>TicketPage.stories</h2>
    </div>
  );
};

export default TicketPageStories;
