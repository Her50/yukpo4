// @ts-check
export const ROUTES = {
  // 🔐 Zones protégées
  PROTECTEDAUDITACCESSPAGE: "/admin/audit-access",

  // 🏠 Pages générales publiques
  HOME: "/",
  LANDING: "/landing",
  LANDING_FR: "/landing/fr",
  LANDING_EN: "/landing/en",
  LANDING_FF: "/landing/ff",
  ABOUT: "/about",
  CONTACT: "/contact",
  SERVICES: "/services",
  PLANS: "/plans",
  LOGIN: "/login",
  REGISTER: "/register",
  CONFIRMATION: "/register/confirmation",

  // 🔔 Fonctionnalités
  VOICE_ASSISTANT: "/voice-assistant",
  PAIEMENTPRO: "/paiementpro",
  MATCH: "/match",
  SERVICE_CREATE: "/services/create",
  SERVICE_DETAIL: (id: string | number) => `/services/${id}`,
  SUGGESTIONS_TEST: "/suggestions-test",

  // ⚙️ Espace personnel
  ESPACE: "/espace",
  MES_OPPORTUNITES: "/dashboard/mes-opportunites",
  MES_SERVICES: "/dashboard/mes-services",
  PROFILE: "/dashboard/mon-profil",

  // 📊 Tableaux de bord
  DASHBOARD: "/dashboard",
  DASHBOARD_HOME: "/dashboard",
  DASHBOARD_STATS: "/dashboard/stats",
  DASHBOARD_API: "/dashboard/api",
  DASHBOARD_IA_PREMIUM: "/dashboard/ia-premium",

  // 🔒 Admin
  DASHBOARD_ADMIN_API: "/admin-api-dashboard",
  DASHBOARD_ADMIN_AUDIT: "/admin-audit-access",

  // 📄 Pages légales
  LEGAL_NOTICE: "/legal/notice",
  PRIVACY: "/legal/privacy",
  COOKIES: "/legal/cookies",
  DOCS: "/docs",

  // 🚪 Routes système
  REDIRECT_AFTER_LOGIN: "/dashboard",
  NOT_FOUND: "/404",

  // ➕ Pages spécifiques aux plans
  PLAN_FREE: "/plans/free",
  PLAN_PRO: "/plans/pro",
  PLAN_ENTERPRISE: "/plans/enterprise"
};
