import React from "react";

const Testimonials: React.FC = () => {
  return (
    <div className="p-4">
      <h2>Testimonials</h2>
    </div>
  );
};

export default Testimonials;
