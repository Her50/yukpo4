import React from "react";

const FeatureGrid: React.FC = () => {
  return (
    <div className="p-4">
      <h2>FeatureGrid</h2>
    </div>
  );
};

export default FeatureGrid;
