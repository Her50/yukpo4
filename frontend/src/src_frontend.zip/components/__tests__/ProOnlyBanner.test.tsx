// @ts-check
import React from "react";
import { render, screen } from "@testing-library/react";
import ProOnlyBanner from "../ProOnlyBanner";
import TestUserProvider from "./TestUserProvider"; // ✅ fonctionne à 100%

describe("ProOnlyBanner", () => {
  it("affiche la bannière si plan = free", () => {
    render(
      <TestUserProvider plan="free">
        <ProOnlyBanner />
      </TestUserProvider>
    );
    expect(screen.getByText(/réservée aux abonnés Pro/i)).toBeInTheDocument();
  });

  it("n'affiche rien si plan = pro", () => {
    render(
      <TestUserProvider plan="pro">
        <ProOnlyBanner />
      </TestUserProvider>
    );
    expect(screen.queryByText(/réservée aux abonnés Pro/i)).not.toBeInTheDocument();
  });

  it("n'affiche rien si plan = enterprise", () => {
    render(
      <TestUserProvider plan="enterprise">
        <ProOnlyBanner />
      </TestUserProvider>
    );
    expect(screen.queryByText(/réservée aux abonnés Pro/i)).not.toBeInTheDocument();
  });
});
