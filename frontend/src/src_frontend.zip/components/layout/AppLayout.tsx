// src/components/layout/AppLayout.tsx
import React, { useEffect } from "react";
import HeaderController from "@/components/HeaderController";
import Footer from "@/components/Footer";
import QuickAccessMenu from "@/components/tools/QuickAccessMenu";
import DevFloatingMenu from "@/components/tools/DevFloatingMenu";

interface AppLayoutProps {
  children: React.ReactNode;
  padding?: boolean;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, padding = true }) => {
  useEffect(() => {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const stored = localStorage.getItem("theme");
    const isDark = stored === "dark" || (!stored && prefersDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  return (
    <>
      <HeaderController />
      <main
        className={`pt-24 min-h-screen bg-gradient-to-br from-yellow-50 via-white to-pink-50 dark:from-gray-900 dark:via-gray-950 dark:to-gray-900 transition-all duration-300 ${
          padding ? "px-4 sm:px-6 lg:px-8" : ""
        }`}
      >
        <div className="max-w-7xl mx-auto relative">
          {children}
        </div>
      </main>
      <Footer />

      {/* ✅ Menus contextuels */}
      <QuickAccessMenu />
      {import.meta.env.DEV && <DevFloatingMenu />}
    </>
  );
};

export default AppLayout;
