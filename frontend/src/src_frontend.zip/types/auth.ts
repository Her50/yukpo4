export type Role = "admin" | "user" | "public";
