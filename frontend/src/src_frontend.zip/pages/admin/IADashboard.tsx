﻿// @ts-check
import React from "react";
import ResponsiveContainer from "@/components/layout/ResponsiveContainer";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const IADashboard: React.FC = () => {
  return (
    <ResponsiveContainer className="py-8">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">🧠 Tableau de bord IA</h1>

      <p className="text-gray-600 mb-4">
        Bienvenue sur le tableau de bord de l’intelligence artificielle{" "}
        <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent font-semibold">Yukpo</span>.
      </p>

      {/* 🚀 CONTEXTUAL BUTTONS */}
      <div className="mt-6 flex flex-wrap gap-4 justify-center">
        <a
          href={ROUTES.SERVICES}
          className="bg-blue-100 text-blue-800 px-4 py-2 rounded hover:bg-blue-200 font-medium"
        >
          Découvrir d'autres services
        </a>
        <a
          href={ROUTES.PLANS}
          className="bg-green-100 text-green-800 px-4 py-2 rounded hover:bg-green-200 font-medium"
        >
          Voir les formules
        </a>
        <a
          href={ROUTES.CONTACT}
          className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded hover:bg-yellow-200 font-medium"
        >
          Contacter l'équipe Yukpo
        </a>
      </div>
    </ResponsiveContainer>
  );
};

export default IADashboard;
