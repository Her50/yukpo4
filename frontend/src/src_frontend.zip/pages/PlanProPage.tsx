import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const PlanProPage = () => (
  <main className="p-10 text-center">
    <h1 className="text-2xl font-bold mb-4">Pla ro</h1>
    <p className="text-gray-600">
      Cette page de Yukpomnang est en construction intelligente.
    </p>
</main>
);

export default PlanProPage;