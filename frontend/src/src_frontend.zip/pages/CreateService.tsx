import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';

import axios from "axios";
import { ROUTES } from "@/routes/AppRoutesRegistry";

export default function CreateService() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    location: "",
  });
  const [link, setLink] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await axios.post("/services/create", form);
      setLink(res.data.link);
    } catch (err) {
      console.error("Erreur lors de la création du service :", err);
    }
  };

  return (
    <div className="">
      <h2 className="text-2xl font-bold mb-4">Publier un service</h2>

      <input
        name="title"
        onChange={handleChange}
        placeholder="Nom du service"
        className="border p-2 w-full mb-2"
      />
      <input
        name="category"
        onChange={handleChange}
        placeholder="Catégorie"
        className="border p-2 w-full mb-2"
      />
      <input
        name="location"
        onChange={handleChange}
        placeholder="Lieu"
        className="border p-2 w-full mb-2"
      />
      <textarea
        name="description"
        onChange={handleChange}
        placeholder="Description"
        className="border p-2 w-full mb-2"
      />
      <button
        onClick={handleSubmit}
        className=""
      >
        Publier
      </button>

      {link && (
        <p className="mt-4">
          Lien généré :{" "}
          <a
            href={link}
            className="text-blue-600 underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            {link}
          </a>
        </p>
      )}

      {/* 🚀 CONTEXTUAL BUTTONS START */}
      <div className="mt-6 flex flex-wrap gap-4 justify-center">
        <a
          href={ROUTES.SERVICES}
          className=""
        >
          Découvrir d'autres services
        </a>
        <a
          href={ROUTES.PLANS}
          className=""
        >
          Voir les formules
        </a>
        <a
          href={ROUTES.CONTACT}
          className=""
        >
          Contacter l'équipe Yukpomnang
        </a>
      </div>
      {/* 🚀 CONTEXTUAL BUTTONS END */}
    </div>
  );
}