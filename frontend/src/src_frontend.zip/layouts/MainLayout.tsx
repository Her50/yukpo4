import React from "react";

const MainLayout: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MainLayout</h2>
    </div>
  );
};

export default MainLayout;
