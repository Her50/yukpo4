// @ts-check
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { ROUTES } from '@/routes/AppRoutesRegistry';
import ProtectedRouteByPlanAndRole from '@/routes/ProtectedRouteByPlanAndRole';
import RequireAuth from '@/components/auth/RequireAuth';

// Pages publiques
import HomePage from '@/pages/HomePage';
import LandingPage from '@/pages/LandingPage';
import LandingPage_FR from '@/pages/landing/LandingPage_fr';
import LandingPage_EN from '@/pages/landing/LandingPage_en';
import LandingPage_FF from '@/pages/landing/LandingPage_ff';
import ApiDocs from '@/pages/docs/ApiDocs';
import LegalNotice from '@/pages/legal/LegalNotice';
import PrivacyPage from '@/pages/legal/PrivacyPage';
import CookiePage from '@/pages/legal/CookiePage';
import AboutPage from '@/pages/AboutPage';
import ServicesPage from '@/pages/ServicesPage';
import ContactPage from '@/pages/ContactPage';
import PlansPage from '@/pages/PlansPage';
import RegisterPage from '@/pages/RegisterPage';
import LoginPage from '@/pages/LoginPage';
import ConfirmationPage from '@/pages/ConfirmationPage';
import CreateService from '@/pages/CreateService';
import VoicePanel from '@/pages/VoicePanel';
import MonEspace from '@/pages/MonEspace';
import PaiementProPage from '@/pages/PaiementProPage';
import MatchPage from '@/pages/MatchPage';
import SingleServicePage from '@/pages/SingleServicePage';
import SuggestionsContextuelles from '@/components/services/SuggestionsContextuelles';

// Plans spécifiques
import PlanFreePage from '@/pages/plans/FreePlanPage';
import PlanProPage from '@/pages/plans/ProPlanPage';
import PlanEnterprisePage from '@/pages/plans/EnterprisePlanPage';

// Pages dashboard et admin
import Dashboard from '@/pages/Dashboard';
import ApiDashboardPage from '@/pages/ApiDashboardPage';
import AdminAccessAudit from '@/pages/admin/AdminAccessAudit';
import MesOpportunitesPage from '@/pages/dashboard/MesOpportunites';
import MesServicesPage from '@/pages/dashboard/MesServices';

// Page 404
import PageNotFound from '@/pages/PageNotFound';

function App() {
  return (
    <Router>
      <Routes>
        {/* 🌐 Pages publiques */}
        <Route path={ROUTES.HOME} element={<HomePage />} />
        <Route path={ROUTES.LANDING} element={<LandingPage />} />
        <Route path={ROUTES.LANDING_FR} element={<LandingPage_FR />} />
        <Route path={ROUTES.LANDING_EN} element={<LandingPage_EN />} />
        <Route path={ROUTES.LANDING_FF} element={<LandingPage_FF />} />
        <Route path={ROUTES.DOCS} element={<ApiDocs />} />
        <Route path={ROUTES.LEGAL_NOTICE} element={<LegalNotice />} />
        <Route path={ROUTES.PRIVACY} element={<PrivacyPage />} />
        <Route path={ROUTES.COOKIES} element={<CookiePage />} />
        <Route path={ROUTES.ABOUT} element={<AboutPage />} />
        <Route path={ROUTES.CONTACT} element={<ContactPage />} />
        <Route path={ROUTES.PLANS} element={<PlansPage />} />
        <Route path={ROUTES.REGISTER} element={<RegisterPage />} />
        <Route path={ROUTES.LOGIN} element={<LoginPage />} />
        <Route path={ROUTES.CONFIRMATION} element={<ConfirmationPage />} />
        <Route path={ROUTES.SERVICES} element={<ServicesPage />} />
        <Route path={ROUTES.SERVICE_CREATE} element={<CreateService />} />
        <Route path={ROUTES.VOICE_ASSISTANT} element={<VoicePanel />} />
        <Route path={ROUTES.ESPACE} element={<MonEspace />} />
        <Route path={ROUTES.PAIEMENTPRO} element={<PaiementProPage />} />
        <Route path={ROUTES.SUGGESTIONS_TEST} element={<SuggestionsContextuelles serviceId={1} />} />
        <Route path={ROUTES.PLAN_FREE} element={<PlanFreePage />} />
        <Route path={ROUTES.PLAN_PRO} element={<PlanProPage />} />
        <Route path={ROUTES.PLAN_ENTERPRISE} element={<PlanEnterprisePage />} />

        {/* 🔐 Pages protégées (plan + rôle) */}
        <Route
          path="/services/:id"
          element={
            <ProtectedRouteByPlanAndRole allowedPlans={['free', 'pro', 'enterprise']}>
              <SingleServicePage />
            </ProtectedRouteByPlanAndRole>
          }
        />
        <Route
          path={ROUTES.DASHBOARD_ADMIN_API}
          element={
            <ProtectedRouteByPlanAndRole allowedRoles={['admin']} allowedPlans={['enterprise']}>
              <ApiDashboardPage />
            </ProtectedRouteByPlanAndRole>
          }
        />
        <Route
          path={ROUTES.DASHBOARD_ADMIN_AUDIT}
          element={
            <ProtectedRouteByPlanAndRole allowedRoles={['admin']} allowedPlans={['enterprise']}>
              <AdminAccessAudit />
            </ProtectedRouteByPlanAndRole>
          }
        />

        {/* 🔐 Utilisateurs connectés */}
        <Route
          path={ROUTES.DASHBOARD}
          element={
            <RequireAuth>
              <Dashboard />
            </RequireAuth>
          }
        />
        <Route
          path={ROUTES.MATCH}
          element={
            <RequireAuth>
              <MatchPage />
            </RequireAuth>
          }
        />
        <Route
          path={ROUTES.MES_OPPORTUNITES}
          element={
            <RequireAuth>
              <MesOpportunitesPage />
            </RequireAuth>
          }
        />
        <Route
          path={ROUTES.MES_SERVICES}
          element={
            <RequireAuth>
              <MesServicesPage />
            </RequireAuth>
          }
        />

        {/* 🚫 Fallback 404 */}
        <Route path="*" element={<PageNotFound />} />
      </Routes>

      <ToastContainer />
    </Router>
  );
}

export default App;
