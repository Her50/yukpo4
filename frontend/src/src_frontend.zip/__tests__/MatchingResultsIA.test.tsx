import React from "react";

const MatchingResultsIATest: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MatchingResultsIA.test</h2>
    </div>
  );
};

export default MatchingResultsIATest;
