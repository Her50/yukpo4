import React from "react";

const MonComposantStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MonComposant.stories</h2>
    </div>
  );
};

export default MonComposantStories;
