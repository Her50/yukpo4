import React from "react";

const CreationPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CreationPage.stories</h2>
    </div>
  );
};

export default CreationPageStories;
