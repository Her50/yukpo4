// src/config/index.ts

export * as MenuConfig from './MenuConfig';       // ✅ correction pour export nommé
export * as plan_pages from './plan_pages';       // ✅ déjà corrigé
