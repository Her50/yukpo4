﻿import React, { useEffect, useState } from 'react';
import i18n from '@/i18n'; // adapte ce chemin selon ton projet

const SUPPORTED_LANGUAGES = [
  { code: 'fr', label: '🇫🇷 Français' },
  { code: 'en', label: '🇬🇧 English' },
  { code: 'ff', label: '🌍 Fulfulde' },
  { code: 'ar', label: '🇸🇦 العربية' },
  { code: 'pt', label: '🇵🇹 Português' },
];

const getBrowserLanguage = (): string => {
  const lang = navigator.language || 'fr';
  return lang.split('-')[0];
};

const LanguageSwitcher: React.FC = () => {
  const [selectedLang, setSelectedLang] = useState('fr');

  useEffect(() => {
    const savedLang = localStorage.getItem('yukpo_lang');
    const browserLang = getBrowserLanguage();

    const detectedLang =
      savedLang && SUPPORTED_LANGUAGES.some(l => l.code === savedLang)
        ? savedLang
        : SUPPORTED_LANGUAGES.some(l => l.code === browserLang)
        ? browserLang
        : 'fr';

    setSelectedLang(detectedLang);
    i18n.changeLanguage(detectedLang);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const lang = e.target.value;
    setSelectedLang(lang);
    i18n.changeLanguage(lang);
    localStorage.setItem('yukpo_lang', lang);
  };

  return (
    <select
      value={selectedLang}
      onChange={handleChange}
      className="text-sm bg-transparent border border-gray-300 dark:border-gray-700 rounded px-2 py-1 outline-none"
      title="Changer de langue"
    >
      {SUPPORTED_LANGUAGES.map((lang) => (
        <option key={lang.code} value={lang.code}>
          {lang.label}
        </option>
      ))}
    </select>
  );
};

export default LanguageSwitcher;
