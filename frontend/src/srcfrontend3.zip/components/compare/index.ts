export { default as CompareTable } from './CompareTable';
export { default as VoteForm } from './VoteForm';
