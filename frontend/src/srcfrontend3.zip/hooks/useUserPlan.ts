// src/hooks/useUserPlan.ts
// @ts-check
import { useUser } from "./useUser";

export const useUserPlan = () => {
  const { user } = useUser();

  const ENABLE_FORCE_PLAN = true; // ← mettre à false en prod

  let plan = user?.plan || "free";

  if (import.meta.env.DEV && ENABLE_FORCE_PLAN) {
    plan = "enterprise";
    console.warn("🧪 Plan forcé à 'enterprise' pour les tests DEV");
  }

  return {
    plan,
    isFree: plan === "free",
    isPro: plan === "pro",
    isEnterprise: plan === "enterprise",
  };
};
