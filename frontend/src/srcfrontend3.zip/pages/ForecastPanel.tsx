import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const ForecastPanel: React.FC = () => {
  return (
    <div className="p-4">
      <h2>ForecastPanel</h2>
    </div>
  );
};

export default ForecastPanel;