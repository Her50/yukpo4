import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface UserPlan {
  id: string;
  email: string;
  plan: string;
  plan_expiry: string | null;
}

const AdminUserPlans: React.FC = () => {
  const [users, setUsers] = useState<UserPlan[]>([]);

  useEffect(() => {
    axios.get('/api/admin/users/plan')
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold mb-4">📅 Plans d’abonnement des utilisateurs</h1>
      {users.map((user) => (
        <Card key={user.id} className="p-4 flex flex-col md:flex-row justify-between items-center">
          <div>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Plan:</strong> {user.plan}</p>
            <p><strong>Expire le:</strong> {user.plan_expiry || '⏳ Jamais activé'}</p>
          </div>
          <Button onClick={() => alert('⚠️ Fonction de changement manuelle à implémenter')}>
            Modifier
          </Button>
        </Card>
      ))}
    </div>
  );
};

export default AdminUserPlans;
