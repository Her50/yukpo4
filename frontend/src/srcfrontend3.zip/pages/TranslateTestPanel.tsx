// @ts-check
import React from "react";

const TranslateTestPanel = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold">🧪 Traduction IA utilisateur</h1>
    <p>Cette page est en cours de construction.</p>
  </div>
);

export default TranslateTestPanel;
