export { default as AccountPage } from './AccountPage';
export { default as Alerts } from './Alerts';
export { default as History } from './History';
export { default as IAPremium } from './IAPremium';
export { default as MesServicesPage } from './MesServicesPage';
export { default as MonProfil } from './MonProfil';
export { default as Overview } from './Overview';
export { default as Services } from './MesServices';
