// 📁 frontend/src/pages/ChatDialog.tsx
import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import ChatHistoryPanel from '@/components/chat/ChatHistoryPanel';

interface Message {
  from: 'client' | 'prestataire';
  content: string;
}

const ChatDialog: React.FC = () => {
  const { client_id } = useParams();
  const prestataire_id = 'me'; // À remplacer par l’ID réel connecté
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const ws = new WebSocket(`wss://localhost:3000/ws/chat/${client_id}`);
    wsRef.current = ws;

    ws.onopen = () => {
      // Message de bienvenue automatique
      const welcome = 'Bonjour 👋, je suis votre prestataire Yukpo. Que puis-je faire pour vous ?';
      ws.send(JSON.stringify({ content: welcome }));
      setMessages([{ from: 'prestataire', content: welcome }]);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setMessages((prev) => [...prev, { from: data.from, content: data.content }]);
    };

    return () => {
      ws.close();
    };
  }, [client_id]);

  const sendMessage = () => {
    if (wsRef.current && newMessage.trim()) {
      wsRef.current.send(JSON.stringify({ content: newMessage }));
      setMessages((prev) => [...prev, { from: 'prestataire', content: newMessage }]);
      setNewMessage('');
    }
  };

  return (
    <AppLayout padding>
      <div className="max-w-3xl mx-auto py-8 px-4">
        <h1 className="text-2xl font-bold mb-4">💬 Chat avec le client #{client_id}</h1>

        {/* 🔁 Historique pré-websocket */}
        <ChatHistoryPanel clientId={client_id || ''} prestataireId={prestataire_id} />

        {/* 📡 Messages WebSocket */}
        <div className="border rounded-md p-4 h-96 overflow-y-auto bg-gray-50 my-6">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`mb-2 ${msg.from === 'prestataire' ? 'text-right' : 'text-left'}`}
            >
              <span className={`inline-block px-3 py-1 rounded-full text-sm ${msg.from === 'prestataire' ? 'bg-blue-200' : 'bg-green-200'}`}>
                {msg.content}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Écrivez un message..."
          />
          <Button onClick={sendMessage}>Envoyer</Button>
        </div>
      </div>
    </AppLayout>
  );
};

export default ChatDialog;
