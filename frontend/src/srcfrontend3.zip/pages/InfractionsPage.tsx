import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const InfractionsPage: React.FC = () => {
  return (
    <div className="p-4">
      <h2>InfractionsPage</h2>
    </div>
  );
};

export default InfractionsPage;