import React, { useState } from 'react';
import axios from 'axios';
import AppLayout from '@/components/layout/AppLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/hooks/useUser';
import { useTranslation } from 'react-i18next';

const RechercheBesoin = () => {
  const [texte, setTexte] = useState('');
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [resultat, setResultat] = useState<Record<string, string | number>[] | null>(null);
  const [objetDetecte, setObjetDetecte] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const { user } = useUser();
  const navigate = useNavigate();
  const planActuel = user?.plan || 'free';
  const { t } = useTranslation();

  const handleAudioUpload = async () => {
    if (!audioFile) return;
    const formData = new FormData();
    formData.append("audio", audioFile);

    try {
      const res = await axios.post("/api/audio-to-text", formData);
      setTexte(res.data.transcription);
    } catch (err) {
      console.error("Erreur transcription audio", err);
    }
  };

  const handleVideoAnalyse = async () => {
    if (!videoFile) return;
    setLoading(true);
    const formData = new FormData();
    formData.append("video", videoFile);

    try {
      const res = await axios.post("/api/detect-lang-video", formData);
      const transcription = res.data.transcription;

      const resType = await axios.post("/api/classify-service-type", { texte: transcription });
      const typeDetecte = resType.data?.type_service || 'general';

      navigate(`/formulaire/${typeDetecte}`);
    } catch (err) {
      console.error("Erreur analyse vidéo", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!texte && !mediaFile) {
      alert(t('form.describe_need'));
      return;
    }

    setLoading(true);
    const formData = new FormData();
    if (mediaFile && planActuel !== 'free') formData.append("media", mediaFile);
    if (texte) formData.append("texte", texte);

    try {
      const resType = await axios.post("/api/classify-service-type", { texte });
      const typeDetecte = resType.data?.type_service || "general";

      if (typeDetecte === "rapide") {
        const resMatch = await axios.post("/api/analyse-visuelle", formData);
        setObjetDetecte(resMatch.data.objet_detecte);
        setResultat(resMatch.data.correspondances);
      } else {
        navigate(`/formulaire/${typeDetecte}`);
      }
    } catch (err) {
      console.error(err);
      alert(t('status.error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout padding>
      <div className="flex flex-col gap-6 items-center max-w-5xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-center text-gray-800">{t('form.describe_need')}</h1>

        <Textarea
          placeholder={t('form.describe_need')}
          value={texte}
          onChange={(e) => setTexte(e.target.value)}
        />

        {/* 📸 Image ou Vidéo */}
        <Input
          type="file"
          accept="image/*,video/*"
          onChange={(e) => e.target.files && setMediaFile(e.target.files[0])}
          disabled={planActuel === 'free'}
        />

        {/* 🎤 Audio */}
        <div className="flex gap-4 items-center w-full">
          <Input
            type="file"
            accept="audio/*"
            onChange={(e) => e.target.files && setAudioFile(e.target.files[0])}
          />
          <Button onClick={handleAudioUpload}>{t('form.transcribe_audio')}</Button>
        </div>

        {/* 🎥 Vidéo directe (abonnements non free) */}
        {planActuel !== 'free' && (
          <div className="w-full flex flex-col gap-2">
            <Input
              type="file"
              accept="video/*"
              onChange={(e) => e.target.files && setVideoFile(e.target.files[0])}
            />
            <Button onClick={handleVideoAnalyse} disabled={loading || !videoFile}>
              {loading ? "Analyse vidéo..." : "Analyser vidéo & rediriger"}
            </Button>
          </div>
        )}

        {/* 💡 Upgrade plan si free */}
        {planActuel === 'free' && (
          <div className="text-sm text-red-600 text-center flex flex-col items-center gap-1">
            {t('matching.restricted_feature')}
            <Button variant="outline" onClick={() => navigate("/plans")}>
              🎁 {t('form.upgrade_plan')}
            </Button>
          </div>
        )}

        {/* 🔍 Soumission générale */}
        <Button onClick={handleSubmit} disabled={loading}>
          {loading ? t('status.loading') : t('form.send')}
        </Button>

        {/* Résultat détecté */}
        {objetDetecte && (
          <p className="text-lg text-gray-600 mt-4">{t('matching.detected_object')}: <strong>{objetDetecte}</strong></p>
        )}

        {/* 🧠 Résultats dynamiques */}
        {resultat && (
          <div className="grid gap-4 mt-6 w-full">
            {resultat.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-4 flex flex-col gap-2">
                  {Object.entries(item).map(([key, value]) => (
                    <p key={key} className="text-sm text-gray-700">
                      <strong>{key}:</strong> {value}
                    </p>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default RechercheBesoin;
