// @ts-check
import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';
import RequireAccess from '@/components/auth/RequireAccess';
import { ROUTES } from "@/routes/AppRoutesRegistry";

const Dashboard: React.FC = () => {
  return (
    <ResponsiveContainer>
      <h1 className="text-3xl font-bold mb-6">
        📊 Tableau de bord Yukpomnang
      </h1>

      <ul className="space-y-2">
        <RequireAccess plan="enterprise">
          <li>
            <Link to={ROUTES.DASHBOARD} className="text-blue-600 underline">
              Accès Yukpomnang Premium
            </Link>
          </li>
        </RequireAccess>
      </ul>

      {/* 🚀 CONTEXTUAL BUTTONS START */}
      <div className="mt-6 flex flex-wrap gap-4 justify-center">
        <Link
          to={ROUTES.SERVICES}
          className="px-4 py-2 bg-blue-100 text-blue-800 rounded-xl hover:bg-blue-200 transition"
        >
          Découvrir d'autres services
        </Link>
        <Link
          to={ROUTES.PLANS}
          className="px-4 py-2 bg-green-100 text-green-800 rounded-xl hover:bg-green-200 transition"
        >
          Voir les formules
        </Link>
        <Link
          to={ROUTES.CONTACT}
          className="px-4 py-2 bg-gray-100 text-gray-800 rounded-xl hover:bg-gray-200 transition"
        >
          Contacter l'équipe Yukpomnang
        </Link>
      </div>
      {/* 🚀 CONTEXTUAL BUTTONS END */}
    </ResponsiveContainer>
  );
};

export default Dashboard;
