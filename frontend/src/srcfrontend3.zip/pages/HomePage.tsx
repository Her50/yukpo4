// src/pages/HomePage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import StarterHero from "@/components/StarterHero";
import WhyUsSection from "@/components/WhyUsSection";
import TestimonialsAndPartners from "@/components/TestimonialsAndPartners";
import FloatingHelpButton from "@/components/FloatingHelpButton";

const HomePage: React.FC = () => {
  return (
    <AppLayout padding={false}>
      <StarterHero />
      <main className="bg-white pt-12">
        <WhyUsSection />
        <TestimonialsAndPartners />
      </main>
      <FloatingHelpButton />
    </AppLayout>
  );
};

export default HomePage;
