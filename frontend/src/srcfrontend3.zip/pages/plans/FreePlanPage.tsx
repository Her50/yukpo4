// ✅ src/pages/plans/FreePlanPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";

const FreePlanPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="py-16 text-center font-sans">
        <h1 className="text-3xl font-bold mb-6 text-primary">🎉 Plan Gratuit Yukpo</h1>
        <p className="mb-4 text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
          Profitez gratuitement de l'essentiel de Yukpo pour découvrir nos services. Idéal pour démarrer sans engagement.
        </p>
        <ul className="list-disc text-left max-w-md mx-auto mb-6 text-gray-700 dark:text-gray-200">
          <li>Accès aux services publics</li>
          <li>Support communautaire</li>
          <li>Nombre d’actions limité</li>
        </ul>
        <a
          href="/register"
          className="btn-primary inline-block px-6 py-2 mt-4"
        >
          S’inscrire gratuitement
        </a>
      </section>
    </AppLayout>
  );
};

export default FreePlanPage;

