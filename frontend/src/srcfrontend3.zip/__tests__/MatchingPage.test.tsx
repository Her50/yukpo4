import React from "react";

const MatchingPageTest: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MatchingPageTest</h2>
    </div>
  );
};

export default MatchingPageTest;
