// 📦 Fichier React : src/components/forms/ServiceFormDynamic.tsx
// ✅ Génère dynamiquement un formulaire à partir du blueprint sélectionné

import React, { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/buttons";
import AppLayout from "@/components/layout/AppLayout";
import { useTranslation } from "react-i18next";
import axios from "axios";

interface ServiceBlueprint {
  id: string;
  categorie: string;
  nature_service: string;
  champs_specifiques: string[];
  gps_required: boolean;
  calcul_distance_bitum: boolean;
  ai_quality_assess: boolean;
}

const ServiceFormDynamic = ({ type }: { type: string }) => {
  const { t } = useTranslation();
  const [blueprint, setBlueprint] = useState<ServiceBlueprint | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [currency, setCurrency] = useState("USD");

  useEffect(() => {
    const fetchBlueprint = async () => {
      try {
        const res = await axios.get(`/api/blueprints/${type}`);
        setBlueprint(res.data);
      } catch (err) {
        console.error("Erreur chargement blueprint:", err);
      }
    };
    fetchBlueprint();
  }, [type]);

  useEffect(() => {
    if (blueprint?.gps_required) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        try {
          const res = await axios.post("/api/geoloc/country", {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setCurrency(res.data.currency || "USD");
        } catch (e) {
          console.warn("Erreur devise:", e);
        }
      });
    }
  }, [blueprint]);

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    try {
      await axios.post("/api/services/create", {
        type,
        data: formData,
        currency,
      });
      alert(t("form.success"));
    } catch (e) {
      alert(t("form.error"));
    }
  };

  return (
    <AppLayout padding>
      <div className="max-w-3xl mx-auto py-10 px-4">
        <h1 className="text-2xl font-bold mb-6">{t("form.create_service")}</h1>

        {blueprint?.champs_specifiques.map((champ) => (
          <div key={champ} className="mb-4">
            <label className="block text-sm font-medium mb-1">
              {t(`fields.${champ}`) || champ}
            </label>
            {champ.includes("description") || champ.includes("detail") ? (
              <Textarea
                value={formData[champ] || ""}
                onChange={(e) => handleChange(champ, e.target.value)}
              />
            ) : (
              <Input
                value={formData[champ] || ""}
                onChange={(e) => handleChange(champ, e.target.value)}
              />
            )}
            {champ === "prix" && currency && (
              <p className="text-sm text-gray-500 mt-1">{t("form.currency")}: {currency}</p>
            )}
          </div>
        ))}

        <Button onClick={handleSubmit} className="mt-6">
          {t("form.submit")}
        </Button>
      </div>
    </AppLayout>
  );
};

export default ServiceFormDynamic;
