import React from "react";

const BrandingSplash: React.FC = () => {
  return (
    <div className="p-4">
      <h2>BrandingSplash</h2>
    </div>
  );
};

export default BrandingSplash;
