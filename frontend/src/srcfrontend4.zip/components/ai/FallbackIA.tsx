import React from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const FallbackIA: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="text-center bg-blue-50 border border-blue-200 p-4 rounded-md mt-8">
      <p className="text-sm text-blue-800">
        💡 Notre IA peut rechercher ce service en dehors de la plateforme (marketplaces, forums, réseaux sociaux…).
      </p>
      <Button className="mt-3" onClick={() => navigate("/contact")}>
        ⚡ Activer la recherche IA avancée
      </Button>
    </div>
  );
};

export default FallbackIA;
