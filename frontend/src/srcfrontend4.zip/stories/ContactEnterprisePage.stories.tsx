import React from "react";

const ContactEnterprisePageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>ContactEnterprisePage.stories</h2>
    </div>
  );
};

export default ContactEnterprisePageStories;
