export const translations = {
  fr: {
    welcome: "Bienvenue sur Yukpomnang",
    explore: "Explorer les services",
  },
  en: {
    welcome: "Welcome to Yukpomnang",
    explore: "Explore Services",
  },
  ff: {
    welcome: "Yukpomnang no tawii",
    explore: "Hollu seɗɗa",
  },
};