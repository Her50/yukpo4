export { default as CookiePage } from './CookiePage';
export { default as LegalNotice } from './LegalNotice';
export { default as PrivacyPage } from './PrivacyPage';
