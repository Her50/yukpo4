// @ts-nocheck
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import AppLayout from "@/components/layout/AppLayout";
import { useUser } from "@/hooks/useUser";
import { useTranslation } from "react-i18next";
import Spinner from "@/components/ui/spinner";
import axios from "axios";
import FallbackIA from "@/components/ia/FallbackIA";

interface ResultItem {
  id: string;
  nom: string;
  description: string;
  prix: string;
  vendeur: string;
  ville: string;
  image_url: string;
  note: number;
  type: string;
  prestataire_id: string;
  source?: "interne" | "externe";
}

const ResultatsBesoin: React.FC = () => {
  const { state } = useLocation();
  const { resultats = [], type = "" }: { resultats: ResultItem[]; type: string } = state || {};
  const { user } = useUser();
  const plan = user?.plan || "free";
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [waiting, setWaiting] = useState(false);
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    if (type === "urgent") {
      setWaiting(true);
      const timer = setTimeout(() => {
        setExpired(true);
        setWaiting(false);
      }, 300000); // 5 min
      return () => clearTimeout(timer);
    }
    return undefined; // ✅ corrigé : tous les chemins retournent une valeur
  }, [type]);

  const getLimit = () => {
    if (plan === "enterprise") return 5;
    if (plan === "pro") return 3;
    return 1;
  };

  const resultsToDisplay = resultats.slice(0, getLimit());

  const trackAction = async (action: string, target: string, meta: object = {}) => {
    if (!user) return;
    try {
      await axios.post("/api/track", {
        user_id: user.id,
        action_type: action,
        action_target: target,
        metadata: meta,
      });
    } catch (err) {
      console.warn("Erreur tracking:", err);
    }
  };

  const handleViewDetails = (id: string) => {
    trackAction("click_view", `service:${id}`);
    navigate(`/services/${id}`);
  };

  const handleContact = (prestataireId: string) => {
    trackAction("click_chat", `prestataire:${prestataireId}`);
    if (plan === "free") {
      alert("🔒 Cette fonctionnalité est réservée aux abonnements Pro et Entreprise.");
      navigate("/plans");
    } else {
      navigate(`/contact-prestataire/${prestataireId}`);
    }
  };

  const handleVitrine = (prestataireId: string) => {
    trackAction("click_vitrine", `vitrine:${prestataireId}`);
    navigate(`/vitrine/${prestataireId}`);
  };

  const noUrgentResults = type !== "urgent" && resultsToDisplay.length === 0;

  useEffect(() => {
    if (noUrgentResults) {
      trackAction("no_match", "resultats_besoin", { type });
    }
  }, [noUrgentResults]);

  return (
    <AppLayout padding>
      <div className="max-w-5xl mx-auto py-10 px-4">
        <h1 className="text-3xl font-bold text-center mb-6">
          {t("matching.similar_results") || "Résultats similaires"}
        </h1>

        {type === "urgent" && waiting && (
          <div className="text-center text-gray-600 my-6">
            <Spinner />
            <p className="mt-2">{t("urgent.searching_message") || "Recherche en cours..."}</p>
          </div>
        )}

        {type === "urgent" && expired && (
          <div className="text-center text-red-600 font-semibold my-6">
            Aucun prestataire n’a encore répondu. Essayez de décocher l’option "urgent" pour avoir plus de résultats.
          </div>
        )}

        {noUrgentResults && (
          <>
            <div className="text-center text-gray-700 bg-yellow-50 border border-yellow-300 p-4 rounded-md mb-6">
              <p className="font-medium">😕 Aucun prestataire ou bien trouvé sur Yukpo pour ce besoin.</p>
              <p className="text-sm mt-2">
                🔍 Si vous avez un plan <strong>Entreprise</strong>, notre moteur IA peut rechercher hors plateforme (marketplaces, réseaux sociaux...).
              </p>
              {plan === "free" && (
                <Button className="mt-3" onClick={() => navigate("/plans")}>
                  🚀 Passer au plan Entreprise
                </Button>
              )}
            </div>
            <FallbackIA />
          </>
        )}

        {resultsToDisplay.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resultsToDisplay.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-5 flex flex-col md:flex-row gap-4">
                  <img
                    src={item.image_url || "/default-image.jpg"}
                    alt={item.nom}
                    className="w-full md:w-32 h-32 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h2 className="font-semibold text-lg">{item.nom}</h2>
                    <p className="text-sm text-gray-600">{item.description}</p>
                    <p className="text-sm font-medium mt-2">💰 {item.prix}</p>
                    <p className="text-sm text-gray-500">🛍 {item.vendeur} – 📍 {item.ville}</p>
                    <p className="text-sm text-yellow-600 mt-1">⭐ {item.note}/5</p>

                    {item.source === "externe" && (
                      <p className="text-xs text-blue-500 mt-1">🌐 Source : externe (recherche IA)</p>
                    )}

                    <div className="flex flex-wrap gap-3 mt-4">
                      <Button size="sm" onClick={() => handleViewDetails(item.id)}>
                        🔍 Voir le détail
                      </Button>
                      {item.type === "service" ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleContact(item.prestataire_id)}
                        >
                          📞 Contacter le prestataire
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleVitrine(item.prestataire_id)}
                        >
                          🛍 Voir sa vitrine
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default ResultatsBesoin;
