// @ts-check
import React from "react";

const PaiementPlanPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold">🧪 Plan de paiement</h1>
    <p>Cette page est en cours de construction.</p>
  </div>
);

export default PaiementPlanPage;
