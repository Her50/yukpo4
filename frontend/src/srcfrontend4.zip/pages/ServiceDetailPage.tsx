import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const ServiceDetailPage = () => (
  <main className="p-10 text-center">
    <h1 className="text-2xl font-bold mb-4">Servic etail</h1>
    <p className="text-gray-600">
      Cette page de Yukpomnang est en construction intelligente.
    </p>
</main>
);

export default ServiceDetailPage;