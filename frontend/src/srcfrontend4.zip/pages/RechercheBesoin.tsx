// 📦 Fichier : RechercheBesoin.tsx
// ✅ Yukpo – Optimisé pour les besoins clients : analyse intelligente + preview + UX multi-format

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AppLayout from '@/components/layout/AppLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/hooks/useUser';
import { useTranslation } from 'react-i18next';
iimport i18n from 'i18next';

const RechercheBesoin = () => {
  const [texte, setTexte] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [audioFiles, setAudioFiles] = useState<File[]>([]);
  const [videoFiles, setVideoFiles] = useState<File[]>([]);
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [siteWeb, setSiteWeb] = useState('');
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(false);

  const { user } = useUser();
  const navigate = useNavigate();
  const planActuel = user?.plan || 'free';
  const { t } = useTranslation();

  // 🌍 Adaptation automatique à la langue utilisateur
  useEffect(() => {
    if (user?.lang) {
      i18n.changeLanguage(user.lang);
    }
  }, [user]);

  // 💬 Suggestions temps réel pendant la saisie
  useEffect(() => {
    const delay = setTimeout(async () => {
      if (texte.length > 5) {
        try {
          const res = await axios.post('/api/suggest-keywords', { texte });
          setSuggestions(res.data.suggestions || []);
        } catch (err) {
          console.warn('Erreur suggestions');
        }
      } else {
        setSuggestions([]);
      }
    }, 500);
    return () => clearTimeout(delay);
  }, [texte]);

  const handlePreview = () => {
    setPreview(true);
  };

  const handleAnalyseGlobale = async () => {
    setLoading(true);
    const formData = new FormData();
    mediaFiles.forEach((file) => formData.append("media", file));
    audioFiles.forEach((file) => formData.append("audio", file));
    videoFiles.forEach((file) => formData.append("video", file));
    if (texte) formData.append("texte", texte);
    if (siteWeb) formData.append("site_web", siteWeb);
    if (excelFile) formData.append("excel", excelFile);
    if (planActuel) formData.append("plan", planActuel);

    try {
      const res = await axios.post('/api/analyse-visuelle', formData);
      const matchData = res.data.correspondances || [];
      navigate('/resultats-besoin', { state: { resultats: matchData, type: 'global' } });
    } catch (err) {
      alert("Une erreur est survenue pendant l’analyse.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout padding>
      <div className="flex flex-col gap-6 items-center max-w-5xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-center text-primary">Décrivez votre besoin avec Yukpo</h1>

        <Textarea
          placeholder={t('form.describe_need')}
          value={texte}
          onChange={(e) => setTexte(e.target.value)}
        />

        {suggestions.length > 0 && (
          <ul className="text-sm text-gray-600 w-full">
            {suggestions.map((sugg, i) => (
              <li key={i} className="text-xs">🔍 {sugg}</li>
            ))}
          </ul>
        )}

        <Input type="file" accept="image/*,video/*" multiple onChange={(e) => setMediaFiles(Array.from(e.target.files || []))} disabled={planActuel === 'free'} />

        <div className="flex gap-4 items-center w-full">
          <Input type="file" accept="audio/*" multiple onChange={(e) => setAudioFiles(Array.from(e.target.files || []))} />
          <Button disabled>{t('form.transcribe_audio')}</Button>
        </div>

        {/* 🌐 Lien vers un produit trouvé ailleurs */}
        <Input type="url" placeholder="🔗 Lien d’un bien ou d’un service que vous avez vu ailleurs..." value={siteWeb} onChange={(e) => setSiteWeb(e.target.value)} />

        <div className="w-full flex gap-3 items-center">
          <Input type="file" accept=".xlsx,.xls" onChange={(e) => setExcelFile(e.target.files?.[0] || null)} />
          <Button onClick={() => {}} disabled={!excelFile}>📄 Joindre un fichier de référence</Button>
        </div>

        {planActuel === 'free' && (
          <div className="text-sm text-red-600 text-center flex flex-col items-center gap-1">
            {t('matching.restricted_feature')}
            <Button variant="outline" onClick={() => navigate("/plans")}>🎁 {t('form.upgrade_plan')}</Button>
          </div>
        )}

        {!preview && (
          <Button onClick={handlePreview} disabled={loading}>Prévisualiser</Button>
        )}

        {preview && (
          <div className="w-full border border-primary/30 rounded-lg p-4 bg-white">
            <h2 className="text-lg font-semibold mb-4">📝 Vérification de votre demande</h2>
            <p><strong>Description :</strong> {texte || 'N/A'}</p>
            <p><strong>Images/Vidéos :</strong> {mediaFiles.length}</p>
            <p><strong>Audios :</strong> {audioFiles.length}</p>
            <p><strong>Vidéos :</strong> {videoFiles.length}</p>
            <p><strong>Site Web :</strong> {siteWeb || 'N/A'}</p>
            <p><strong>Fichier joint :</strong> {excelFile?.name || 'Aucun'}</p>
            <Button className="mt-4" onClick={handleAnalyseGlobale}>📤 Analyser et afficher les résultats</Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default RechercheBesoin;
