import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ROUTES } from '@/routes/AppRoutesRegistry';
import OAuthButton from '@/components/auth/OAuthButton';

const LoginPage: React.FC = () => {
  const location = useLocation();
  const [showLogoutMessage, setShowLogoutMessage] = useState(false);

  useEffect(() => {
    if (location.state?.loggedOut) {
      setShowLogoutMessage(true);
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  return (
    <main className="min-h-screen pt-28 bg-gradient-to-br from-yellow-50 via-white to-red-50 dark:from-gray-900 dark:via-gray-950 dark:to-gray-900">
      <div className="max-w-md mx-auto bg-white dark:bg-gray-900 shadow-xl rounded-xl p-8">
        {showLogoutMessage && (
          <div className="mb-4 bg-green-100 text-green-800 px-4 py-2 rounded shadow text-center">
            ✅ Vous êtes bien déconnecté.
          </div>
        )}

        <h1 className="text-3xl font-bold text-center mb-4">
          Connexion à{" "}
          <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
            Yukpo
          </span>
        </h1>

        <p className="text-center text-gray-600 dark:text-gray-300 mb-6">
          Connectez-vous avec votre compte <strong>Google</strong> ou <strong>Facebook</strong>
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-6">
          <OAuthButton provider="google" />
          <OAuthButton provider="facebook" />
        </div>

        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-4">
          ou utilisez vos identifiants :
        </p>

        <form className="flex flex-col gap-4">
          <input
            type="email"
            placeholder="Adresse email"
            className="p-3 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
          <input
            type="password"
            placeholder="Mot de passe"
            className="p-3 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
          <button className="bg-primary hover:bg-primary/90 text-white py-2 rounded-md transition font-semibold">
            Se connecter
          </button>
        </form>

        <p className="text-center text-sm mt-6 text-gray-700 dark:text-gray-300">
          Pas encore inscrit ?{" "}
          <Link to={ROUTES.REGISTER} className="text-primary underline font-medium">
            Créer un compte
          </Link>
        </p>
      </div>
    </main>
  );
};

export default LoginPage;
