
// ✅ src/pages/plans/EnterprisePlanPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";

const EnterprisePlanPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="py-16 px-6 font-sans max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-red-600 mb-6">🏢 Plan Entreprise Yukpo</h1>
        <p className="mb-6 text-gray-700 dark:text-gray-300">
          Destiné aux entreprises, institutions ou grands comptes. Yukpo vous propose un accompagnement sur mesure, des modules étendus, et un support dédié.
        </p>
        <ul className="text-left text-gray-800 dark:text-gray-200 list-disc mb-6 max-w-2xl mx-auto">
          <li>Tableaux de bord avancés</li>
          <li>Accès aux API IA + connecteurs personnalisés</li>
          <li>Support stratégique dédié</li>
          <li>Formation et onboarding sur demande</li>
        </ul>
        <form className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow max-w-md mx-auto">
          <h2 className="text-xl font-semibold mb-4">📬 Demander une démo personnalisée</h2>
          <input
            type="text"
            name="nom"
            placeholder="Nom complet"
            required
            className="input w-full mb-3"
          />
          <input
            type="email"
            name="email"
            placeholder="Adresse email professionnelle"
            required
            className="input w-full mb-3"
          />
          <textarea
            name="message"
            rows={4}
            placeholder="Expliquez vos besoins spécifiques"
            className="input w-full mb-4"
          />
          <button
            type="submit"
            className="btn-primary w-full"
          >
            Demander une démo Yukpo
          </button>
        </form>
      </section>
    </AppLayout>
  );
};

export default EnterprisePlanPage;
