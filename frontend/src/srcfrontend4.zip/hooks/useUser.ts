// src/hooks/useUser.ts
// @ts-check
import { jwtDecode } from 'jwt-decode';

export type Role = 'admin' | 'user' | 'client' | 'public';

export interface DecodedToken {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  exp: number;
  name?: string;
  photo?: string;
  picture?: string;
}

export interface User {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  isAdmin: boolean;
  isUser: boolean;
  name: string;
  photo: string;
}

export function useUser(): {
  user: User | null;
  login: (token: string) => void;
  logout: () => void;
} {
  const token = localStorage.getItem('token');
  const isFakeUserMode = localStorage.getItem('__DEV_FAKE_USER__') === 'true';
  let user: User | null = null;

  if (token) {
    try {
      const decoded = jwtDecode<DecodedToken>(token);
      if (decoded.exp * 1000 > Date.now()) {
        user = {
          id: decoded.id,
          email: decoded.email,
          role: decoded.role,
          plan: decoded.plan,
          isAdmin: decoded.role === 'admin',
          isUser: decoded.role === 'user',
          name: decoded.name || '',
          photo: decoded.photo || decoded.picture || '',
        };
      } else {
        localStorage.removeItem('token');
      }
    } catch (e) {
      localStorage.removeItem('token');
    }
  }

  // ✅ MODE DEV : injecte un utilisateur fictif si activé
  if (!user && import.meta.env.DEV && isFakeUserMode) {
    user = {
      id: "fake-dev-id",
      email: "admin@yukpo.dev",
      role: "admin",
      plan: "enterprise",
      isAdmin: true,
      isUser: false,
      name: "Dev Admin",
      photo: "",
    };
    console.warn("🧪 UTILISATEUR DE DÉVELOPPEMENT ACTIVÉ — via localStorage");
  }

  // 🔁 Bascule dynamique via console
  if (typeof window !== "undefined") {
    // @ts-ignore
    window.__YUKPOMNANG_TOGGLE_DEV = () => {
      const current = localStorage.getItem('__DEV_FAKE_USER__') === 'true';
      localStorage.setItem('__DEV_FAKE_USER__', current ? 'false' : 'true');
      window.location.reload();
    };
  }

  return {
    user,
    login: (token: string) => {
      localStorage.setItem('token', token);
      window.location.reload();
    },
    logout: () => {
      localStorage.removeItem('token');
      localStorage.removeItem('__DEV_FAKE_USER__');
      window.location.reload();
    },
  };
}
