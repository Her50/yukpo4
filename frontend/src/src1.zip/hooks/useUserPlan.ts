// @ts-check
import { useUser } from "./useUser";

export const useUserPlan = () => {
  const { user } = useUser();

  // Exemple : user.plan = "pro" | "enterprise"
  const plan = user?.plan || "free";

  return {
    plan,
    isFree: plan === "free",
    isPro: plan === "pro",
    isEnterprise: plan === "enterprise",
  };
};
