import React from "react";

const AccessControlTest: React.FC = () => {
  return (
    <div className="p-4">
      <h2>AccessControl.test</h2>
    </div>
  );
};

export default AccessControlTest;
