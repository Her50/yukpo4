// @ts-check
export const ROUTES = {
  PROTECTEDAUDITACCESSPAGE: "/admin/audit-access",

  HOME: "/",
  LANDING: "/landing",
  LANDING_FR: "/landing/fr",
  LANDING_EN: "/landing/en",
  LANDING_FF: "/landing/ff",
  DOCS: "/docs",
  LEGAL_NOTICE: "/legal/notice",
  PRIVACY: "/legal/privacy",
  COOKIES: "/legal/cookies",
  CONTACT: "/contact",
  REGISTER: "/register",
  DASHBOARD: "/dashboard",
  LOGIN: "/login",
  PLANS: "/plans",
  SERVICES: "/services",
  ABOUT: "/about",
  CONFIRMATION: "/register/confirmation",
  ESPACE: "/espace",
  VOICE_ASSISTANT: "/voice-assistant",
  SERVICE_CREATE: "/services/create",
  SERVICE_DETAIL: (id: string | number) => `/services/${id}`,

  PLAN_PRO: "/plans/pro",
  PLAN_ENTERPRISE: "/plans/enterprise",

  DASHBOARD_HOME: "/dashboard",
  DASHBOARD_IA_PREMIUM: "/dashboard/ia-premium",
  DASHBOARD_MES_SERVICES: "/dashboard/mes-services",
  DASHBOARD_STATS: "/dashboard/stats",
  DASHBOARD_API: "/dashboard/api",
  PROFILE: "/dashboard/mon-profil",

  DASHBOARD_ADMIN_API: "/admin-api-dashboard",
  DASHBOARD_ADMIN_AUDIT: "/admin-audit-access",

  SUGGESTIONS_TEST: "/suggestions-test",

  REDIRECT_AFTER_LOGIN: "/dashboard",
  NOT_FOUND: "/404",
};
