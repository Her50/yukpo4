import React from "react";

const AdminPanelStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>AdminPanel Stories</h2>
    </div>
  );
};

export default AdminPanelStories;
