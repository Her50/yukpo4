import React from "react";

const AdminAnalyticsPanelStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>AdminAnalyticsPanel Stories</h2>
    </div>
  );
};

export default AdminAnalyticsPanelStories;
