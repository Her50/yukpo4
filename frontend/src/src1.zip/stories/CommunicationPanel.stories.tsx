import React from "react";

const CommunicationPanelStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CommunicationPanel.stories</h2>
    </div>
  );
};

export default CommunicationPanelStories;
