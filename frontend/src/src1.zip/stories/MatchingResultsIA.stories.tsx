import React from "react";

const MatchingResultsIAStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MatchingResultsIA.stories</h2>
    </div>
  );
};

export default MatchingResultsIAStories;
