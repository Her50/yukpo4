import React from "react";

const AboutPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>AboutPage Stories</h2>
    </div>
  );
};

export default AboutPageStories;
