import React from "react";

const NewsletterSignup: React.FC = () => {
  return (
    <div className="p-4">
      <h2>NewsletterSignup</h2>
    </div>
  );
};

export default NewsletterSignup;
