﻿// src/components/Footer.tsx
import React from "react";
import { Link } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const Footer: React.FC = () => (
  <footer className="w-full border-t px-4 py-6 text-sm bg-white dark:bg-gray-900 dark:text-gray-400 text-gray-600">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <p>
        <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent font-bold">
          Yukpo
        </span>{" "}
        © 2025 — Tous droits réservés.
      </p>

      <nav className="flex flex-wrap gap-4 text-sm">
        <Link to={ROUTES.LEGAL_NOTICE} className="hover:underline">
          Mentions légales
        </Link>
        <Link to={ROUTES.PRIVACY} className="hover:underline">
          Confidentialité
        </Link>
        <Link to={ROUTES.COOKIES} className="hover:underline">
          Cookies
        </Link>
        <Link to={ROUTES.ABOUT} className="hover:underline">
          À propos
        </Link>
      </nav>
    </div>
  </footer>
);

export default Footer;
