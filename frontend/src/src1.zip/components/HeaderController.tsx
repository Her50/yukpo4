// src/components/HeaderController.tsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";
import DesktopMenu from "@/components/DesktopMenu";
import MobileMenu from "@/components/MobileMenu";
import LangSwitcher from "@/components/LangSwitcher";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";
import { ROUTES } from "@/routes/AppRoutesRegistry";

type Role = "admin" | "client" | "user";

const HeaderController: React.FC = () => {
  const { user } = useUser();
  const { plan } = useUserPlan();
  const [theme, setTheme] = useState<string>("light");

  const roleLabel: Record<Role, string> = {
    admin: "Admin",
    client: "Client",
    user: "Utilisateur",
  };

  // Initialiser le thème depuis le localStorage ou les préférences système
  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const active = stored || (systemDark ? "dark" : "light");
    setTheme(active);
    document.documentElement.classList.toggle("dark", active === "dark");
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  return (
    <header className="fixed top-0 left-0 w-full h-24 z-50 bg-white dark:bg-gray-900 shadow-md px-4 sm:px-8 lg:px-12 flex items-center justify-between font-sans">
      <Link to={ROUTES.HOME} className="flex items-center gap-2">
        <img
          src={logo}
          alt="Yukpo"
          className="h-12 w-auto object-contain"
        />
      </Link>

      <div className="flex items-center gap-4">
        <DesktopMenu />

        {user ? (
          <div className="hidden md:flex flex-col text-xs text-right leading-tight text-gray-600 dark:text-gray-300">
            <span>Rôle : <strong>{roleLabel[user.role as Role]}</strong></span>
            <span>Plan : <strong>{plan}</strong></span>
          </div>
        ) : (
          <div className="hidden md:flex items-center gap-2">
            <Link to={ROUTES.LOGIN} className="px-4 py-2 text-sm border border-primary rounded-full text-primary hover:bg-primary hover:text-white transition">
              Connexion
            </Link>
            <Link to={ROUTES.REGISTER} className="px-4 py-2 text-sm bg-yellow-400 hover:bg-yellow-500 rounded-full text-black">
              S’inscrire
            </Link>
          </div>
        )}

        {/* ☀️🌙 Switcher de thème */}
        <button
          onClick={toggleTheme}
          className="text-xl hover:scale-110 transition-transform"
          title="Changer de thème"
        >
          {theme === "dark" ? "🌙" : "☀️"}
        </button>

        <LangSwitcher />
        <MobileMenu />
      </div>
    </header>
  );
};

export default HeaderController;
