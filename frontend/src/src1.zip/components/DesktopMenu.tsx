// src/components/DesktopMenu.tsx
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";

const DesktopMenu: React.FC = () => {
  const { user } = useUser();
  const { plan } = useUserPlan();
  const location = useLocation();
  const current = location.pathname;

  const isConnected = !!user;

  const links = [
    { path: ROUTES.HOME, label: "Accueil" },
    { path: ROUTES.SERVICES, label: "Services" },
    { path: ROUTES.PLANS, label: "Abonnement" },
    { path: ROUTES.CONTACT, label: "Contact" },
    { path: ROUTES.ABOUT, label: "À propos" },
  ];

  if (isConnected) {
    links.push({ path: ROUTES.ESPACE, label: "Mon Espace" });

    if (user?.role === "admin") {
      links.push({ path: ROUTES.DASHBOARD_ADMIN_AUDIT, label: "Audit sécurité" });
    }

    if (["pro", "enterprise"].includes(plan)) {
      links.push({ path: ROUTES.DASHBOARD_MES_SERVICES, label: "Mes Services" });
    }

    if (plan === "enterprise") {
      links.push({ path: ROUTES.DASHBOARD_STATS, label: "Statistiques" });
      links.push({ path: ROUTES.DASHBOARD_API, label: "API IA" });
    }
  }

  return (
    <ul className="hidden md:flex items-center flex-wrap gap-4 text-sm md:text-base text-gray-800 font-medium">
      {links.map(({ path, label }) => (
        <li key={path}>
          <Link
            to={path}
            className={`hover:text-primary transition-colors ${
              current === path ? "text-primary underline underline-offset-4 font-bold" : ""
            }`}
          >
            {label}
          </Link>
        </li>
      ))}
    </ul>
  );
};

export default DesktopMenu;
