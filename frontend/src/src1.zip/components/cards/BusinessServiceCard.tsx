// src/components/BusinessServiceCard.tsx
import React from 'react';
import StarRating from '@/components/notation/StarRating';
import { ROUTES } from '@/routes/AppRoutesRegistry'; // ✅ Import ajouté

interface BusinessServiceCardProps {
  nom: string;
  description: string;
  categorie?: string;
  prix?: number;
  plan_requis?: 'free' | 'pro' | 'enterprise';
  badge?: string;
  badgeColor?: string;
  note?: number;
  showNote?: boolean;
  onClick?: () => void;
}

const BusinessServiceCard: React.FC<BusinessServiceCardProps> = ({
  nom,
  description,
  categorie,
  prix,
  plan_requis,
  badge,
  badgeColor = '#007bff',
  note = 3,
  showNote = true,
  onClick,
}) => {
  return (
    <div
      className="relative p-4 border rounded-xl shadow-md bg-white hover:shadow-lg transition"
      onClick={onClick}
    >
      {badge && (
        <div
          className="absolute top-2 right-2 text-xs px-2 py-1 text-white rounded-full font-bold"
          style={{ backgroundColor: badgeColor }}
        >
          {badge}
        </div>
      )}

      <h3 className="text-xl font-bold mb-1">{nom}</h3>
      <p className="text-sm text-gray-600 mb-2">{description}</p>

      {categorie && (
        <span className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded-full inline-block mb-2">
          {categorie}
        </span>
      )}

      {prix !== undefined && (
        <p className="text-green-600 font-semibold">
          {prix.toLocaleString()} FCFA
        </p>
      )}

      {showNote && (
        <div className="mt-2">
          <StarRating note={note} />
        </div>
      )}

      {plan_requis && (
        <div className="mt-4 text-right">
          {plan_requis === 'free' ? (
            <button
              className="px-4 py-1 bg-green-500 text-white rounded hover:bg-green-600"
              onClick={() => (window.location.href = ROUTES.SERVICES)}
            >
              Tester ce service
            </button>
          ) : (
            <button
              className="px-4 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
              onClick={() => (window.location.href = `${ROUTES.PLANS}/${plan_requis}`)}
            >
              Passer au plan {plan_requis.toUpperCase()}
            </button>
          )}
        </div>
      )}

      {/* 🚀 CONTEXTUAL BUTTONS */}
      <div className="mt-6 flex flex-wrap gap-4 justify-center border-t pt-6">
        <a
          href={ROUTES.SERVICES}
          className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 transition"
        >
          Découvrir d'autres services
        </a>
        <a
          href={ROUTES.PLANS}
          className="px-4 py-2 bg-yellow-400 text-black rounded hover:bg-yellow-500 transition"
        >
          Voir les formules
        </a>
        <a
          href={ROUTES.CONTACT}
          className="px-4 py-2 bg-gray-100 border rounded hover:bg-gray-200 transition"
        >
          Contacter l'équipe Yukpomnang
        </a>
      </div>
    </div>
  );
};

export default BusinessServiceCard;
