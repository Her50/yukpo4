import React from "react";
import { ROUTES } from "@/routes/AppRoutesRegistry";
import { Link } from "react-router-dom";

interface Props {
  nom: string;
  description: string;
  prix: number;
  categorie: string;
}

const ServiceCard: React.FC<Props> = ({ nom, description, prix, categorie }) => {
  return (
    <div className="rounded-xl border shadow-sm p-6 bg-white dark:bg-gray-900 flex flex-col justify-between h-full hover:shadow-md transition-all">
      <div>
        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{nom}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{description}</p>
        <p className="text-sm text-gray-500 mb-1">
          <strong>Catégorie :</strong> {categorie}
        </p>
        <p className="text-sm text-gray-500">
          <strong>Prix :</strong> {prix.toLocaleString()} FCFA
        </p>
      </div>

      <div className="mt-6 flex flex-col gap-2">
        <Link
          to={ROUTES.PLANS}
          className="px-4 py-2 bg-yellow-400 text-black rounded hover:bg-yellow-500 text-center font-medium"
        >
          Voir les formules
        </Link>
        <Link
          to={ROUTES.CONTACT}
          className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border rounded hover:bg-gray-200 dark:hover:bg-gray-600 text-center font-medium"
        >
          Contacter Yukpomnang
        </Link>
      </div>
    </div>
  );
};

export default ServiceCard;
