import React from 'react';

interface RequireAuthProps {
  children: React.ReactNode;
}

const RequireAuth: React.FC<RequireAuthProps> = ({ children }) => {
  // logique d'authentification
  const isAuthenticated = true; // remplace par ta logique réelle

  if (!isAuthenticated) {
    return <p>Accès refusé. Veuillez vous connecter.</p>;
  }

  return <>{children}</>;
};

export default RequireAuth;
