import { ReactNode } from "react";
import { useUserContext } from "@/context/UserContext";

interface RequireAccessProps {
  role?: string;              // Ex: "admin"
  anyOf?: string[];           // Ex: ["admin", "client"]
  allOf?: string[];           // Ex: ["client", "user"]
  not?: string;               // Ex: "public"
  plan?: "free" | "pro" | "enterprise";
  children: ReactNode;
  fallback?: ReactNode;
}

const RequireAccess: React.FC<RequireAccessProps> = ({
  role,
  anyOf,
  allOf,
  not,
  plan,
  children,
  fallback = null,
}) => {
  const { user } = useUserContext();

  if (!user) return <>{fallback}</>;

  const roles: string[] = user.roles ?? [];
  const currentPlan: string = user.plan ?? "";

  if (plan && currentPlan !== plan) return <>{fallback}</>;
  if (role && !roles.includes(role)) return <>{fallback}</>;
  if (anyOf && !anyOf.some((r) => roles.includes(r))) return <>{fallback}</>;
  if (allOf && !allOf.every((r) => roles.includes(r))) return <>{fallback}</>;
  if (not && roles.includes(not)) return <>{fallback}</>;

  return <>{children}</>;
};

export default RequireAccess;
