// src/components/security/RequirePlan.tsx
import React from "react";
import { useUserContext } from "@/context/UserContext";

interface RequirePlanProps {
  plan: "free" | "pro" | "enterprise";
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const RequirePlan: React.FC<RequirePlanProps> = ({ plan, children, fallback = null }) => {
  const { user } = useUserContext();

  if (!user || user.plan !== plan) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

export default RequirePlan;
