// src/components/layout/AppLayout.tsx
import React, { useEffect } from "react";
import HeaderController from "@/components/HeaderController";
import Footer from "@/components/Footer";

interface AppLayoutProps {
  children: React.ReactNode;
  padding?: boolean;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, padding = true }) => {
  useEffect(() => {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const stored = localStorage.getItem("theme");
    if (stored === "dark" || (!stored && prefersDark)) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, []);

  return (
    <>
      <HeaderController />
      <main className={`pt-24 min-h-screen ${padding ? "px-4 sm:px-6 lg:px-8" : ""} bg-white dark:bg-gray-950`}>
        <div className="max-w-7xl mx-auto">{children}</div>
      </main>
      <Footer />
    </>
  );
};

export default AppLayout;
