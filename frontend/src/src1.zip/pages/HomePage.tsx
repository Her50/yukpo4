import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';

import StarterHero from "@/components/StarterHero";
import WhyUsSection from "@/components/WhyUsSection";
import TestimonialsAndPartners from "@/components/TestimonialsAndPartners";
import FloatingHelpButton from "@/components/FloatingHelpButton";
import HeaderController from "@/components/HeaderController";

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-red-50">
      <HeaderController />
      <StarterHero />
      <main className="bg-white pt-12">
          <WhyUsSection />
          <TestimonialsAndPartners />
</main>
      <FloatingHelpButton />
    </div>
  );
};

export default HomePage;