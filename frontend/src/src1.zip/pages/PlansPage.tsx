import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const PlansPage: React.FC = () => {
  return (
    <main className="">
      <h1 className="text-3xl font-bold mb-6">Nos formules d’abonnement</h1>
      <p className="mb-4 text-gray-600">
        Découvrez les offres de Yukpomnang adaptées à vos besoins.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
        <div className="border rounded-xl p-6 shadow-sm hover:shadow-lg transition">
          <h2 className="text-xl font-semibold mb-2">Free</h2>
          <p className="text-sm text-gray-500 mb-4">Gratuit avec accès limité</p>
          <button className="">
            Choisir
          </button>
        </div>
        <div className="border rounded-xl p-6 shadow-md hover:shadow-lg transition">
          <h2 className="text-xl font-semibold mb-2">Pro</h2>
          <p className="text-sm text-gray-500 mb-4">Accès complet aux modules essentiels</p>
          <button className="" onClick={() => window.location.href="/s’abonner"}>s’abonner</button>
        </div>
        <div className="border rounded-xl p-6 shadow-lg hover:shadow-xl transition">
          <h2 className="text-xl font-semibold mb-2">Enterprise</h2>
          <p className="text-sm text-gray-500 mb-4">Tous les services + options avancées</p>
          <button className="" onClick={() => window.location.href="/nous-contacter"}>nous contacter</button>
        </div>
      </div>
</main>
  );
};

export default PlansPage;