import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';

import { useLocation, Link } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";
import OAuthButton from "@/components/auth/OAuthButton";

const LoginPage: React.FC = () => {
  const location = useLocation();
  const [showLogoutMessage, setShowLogoutMessage] = useState(false);

  useEffect(() => {
    if (location.state?.loggedOut) {
      setShowLogoutMessage(true);
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  return (
    <main className="min-h-screen bg-red-50 pt-24">
        {showLogoutMessage && (
          <div className="mb-4 bg-green-100 text-green-800 px-4 py-2 rounded shadow text-center">
            ✅ Vous êtes bien déconnecté.
          </div>
        )}

        <h1 className="text-3xl font-bold mb-6 text-center">
          Connexion à{" "}
          <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
            Yukpo
          </span>
        </h1>

        <p className="text-center text-gray-600 mb-4">
          Connectez-vous rapidement avec votre compte{" "}
          <strong>Google</strong> ou <strong>Facebook</strong> :
        </p>

        <div className="flex justify-center gap-4 mb-6">
          <OAuthButton provider="google" />
          <OAuthButton provider="facebook" />
        </div>

        <p className="text-center text-sm text-gray-500 mb-4">
          ou entrez vos identifiants manuellement
        </p>

        <form className="flex flex-col gap-4 max-w-md mx-auto">
          <input
            type="email"
            placeholder="Adresse email"
            className="border p-2 rounded"
            required
          />
          <input
            type="password"
            placeholder="Mot de passe"
            className="border p-2 rounded"
            required
          />
          <button className="bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
            Se connecter
          </button>
        </form>

        <p className="text-center text-sm mt-6">
          Pas encore inscrit ?{" "}
          <Link to={ROUTES.REGISTER} className="text-primary underline">
            Créer un compte
          </Link>
        </p>
    </main>
  );
};

export default LoginPage;