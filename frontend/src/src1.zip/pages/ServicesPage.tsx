// @ts-check
import React from "react";
import { useNavigate, Link } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import RequireAccess from "@/components/auth/RequireAccess";
import ProductGrid from "@/components/services/ProductGrid";
import SuggestionsContextuelles from "@/components/services/SuggestionsContextuelles";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const ServicesPage: React.FC = () => {
  const navigate = useNavigate();

  const handleClick = (key: string) => {
    navigate(`/about${key}`);
  };

  return (
    <AppLayout>
      <RequireAccess role="user" plan="pro">
        <section className="py-16 font-sans">
          <h2 className="text-4xl font-bold text-center mb-10 text-gray-900 dark:text-white">
            🚀 Nos 3 Produits Phare
          </h2>

          <ProductGrid onClick={handleClick} />

          <div className="mt-12">
            <SuggestionsContextuelles serviceId={1} />
          </div>

          {/* 🚀 CONTEXTUAL BUTTONS */}
          <div className="mt-16 flex flex-wrap gap-4 justify-center text-sm">
            <Link
              to={ROUTES.SERVICES}
              className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 transition"
            >
              Découvrir d'autres services
            </Link>
            <Link
              to={ROUTES.PLANS}
              className="px-4 py-2 bg-yellow-400 text-black rounded hover:bg-yellow-500 transition"
            >
              Voir les formules
            </Link>
            <Link
              to={ROUTES.CONTACT}
              className="px-4 py-2 bg-gray-100 text-gray-800 border rounded hover:bg-gray-200 transition"
            >
              Contacter l'équipe Yukpomnang
            </Link>
          </div>
        </section>
      </RequireAccess>
    </AppLayout>
  );
};

export default ServicesPage;
