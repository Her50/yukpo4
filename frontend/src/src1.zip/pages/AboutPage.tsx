// @ts-check
import React from "react";
import ResponsiveContainer from "@/components/layout/ResponsiveContainer";

const AboutPage: React.FC = () => {
  return (
    <main className="pt-24 min-h-screen bg-yellow-50 font-sans">
      <ResponsiveContainer>
        <h2 className="text-3xl font-bold mb-4 text-primary">
          À propos de{" "}
          <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent font-bold">
            Yukpo
          </span>
        </h2>

        <p className="text-gray-700 leading-relaxed mb-4">
          <span className="font-semibold text-primary">Yukpo</span> est une plateforme intelligente qui écoute, comprend et agit selon vos besoins.
          Propulsée par l'IA, elle vous connecte aux meilleures solutions disponibles.
        </p>

        <p className="text-gray-700 leading-relaxed mb-4">
          Notre système d'interaction vocale, de recommandation intelligente et d’analyse prédictive vous permet
          d’accéder à des services rapides, pertinents et personnalisés à tout moment.
        </p>

        <p className="text-gray-700 leading-relaxed">
          Que vous soyez client ou prestataire,{" "}
          <span className="font-semibold text-primary">Yukpo</span> simplifie votre quotidien avec une technologie accessible,
          multilingue et pensée pour l’Afrique.
        </p>
      </ResponsiveContainer>
    </main>
  );
};

export default AboutPage;
