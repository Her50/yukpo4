import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


const CaptchaPage: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CaptchaPage</h2>
    </div>
  );
};

export default CaptchaPage;