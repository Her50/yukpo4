// @ts-check
import React from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';
import RequireAccess from '@/components/auth/RequireAccess';
import styled, { keyframes } from "styled-components";

// Animation MatchPage
const pulse = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.05); opacity: 0.75; }
  100% { transform: scale(1); opacity: 1; }
`;

// Styled component
const PulseBox = styled.div`
  animation: ${pulse} 2s infinite;
`;

const MatchPage: React.FC = () => {
  const data = {
    plan: "free", // à remplacer par une vraie vérification avec useUser() ou context
    ia_response: "Voici les correspondances Yukpomnang générées selon votre besoin.",
  };

  return (
    <ResponsiveContainer>
      <div className="font-sans">
        <h1 className="text-3xl font-bold mb-6">🎯 Mise en relation intelligente</h1>

        <PulseBox className="bg-gray-100 p-6 rounded-lg shadow text-center">
          <p className="text-lg font-medium text-gray-700">{data.ia_response}</p>
        </PulseBox>

        {data.plan === "free" && (
          <div className="mt-6 text-center text-red-600 font-semibold">
            Certaines suggestions Premium sont désactivées. <br />
            <RequireAccess plan="pro">
              Mettez à jour votre plan pour débloquer tout le potentiel de l’IA.
            </RequireAccess>
          </div>
        )}
      </div>
    </ResponsiveContainer>
  );
};

export default MatchPage;
