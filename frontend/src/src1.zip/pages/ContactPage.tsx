// src/pages/ContactPage.tsx
import React, { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";

const ContactPage: React.FC = () => {
  const [form, setForm] = useState({ nom: "", email: "", message: "" });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      setForm({ nom: "", email: "", message: "" });
    }, 1000);
  };

  return (
    <AppLayout>
      <section className="py-16 font-sans">
        <h1 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">
          📬 Contactez Yukpomnang
        </h1>

        <div className="max-w-xl mx-auto bg-white dark:bg-gray-900 shadow-md rounded-xl p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <input
              type="text"
              name="nom"
              placeholder="Votre nom"
              value={form.nom}
              onChange={handleChange}
              required
              className="w-full p-3 border rounded dark:bg-gray-800 dark:text-white"
            />
            <input
              type="email"
              name="email"
              placeholder="Votre email"
              value={form.email}
              onChange={handleChange}
              required
              className="w-full p-3 border rounded dark:bg-gray-800 dark:text-white"
            />
            <textarea
              name="message"
              placeholder="Votre message"
              value={form.message}
              onChange={handleChange}
              required
              className="w-full p-3 border rounded h-32 resize-none dark:bg-gray-800 dark:text-white"
            />

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-primary text-white rounded font-semibold hover:bg-opacity-90 transition"
            >
              {loading ? "Envoi en cours..." : "Envoyer le message"}
            </button>

            {sent && (
              <div className="text-green-600 text-center font-semibold mt-4">
                ✅ Message envoyé avec succès !
              </div>
            )}
          </form>
        </div>
      </section>
    </AppLayout>
  );
};

export default ContactPage;
