import React, { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";

type Role = "admin" | "client" | "user";
type Plan = "free" | "pro" | "enterprise";

interface Props {
  children: ReactNode;
  allowedRoles?: Role[];
  allowedPlans?: Plan[];
}

const ProtectedRouteByPlanAndRole: React.FC<Props> = ({
  children,
  allowedRoles,
  allowedPlans
}) => {
  const { user } = useUser();
  const { plan } = useUserPlan();

  const hasAccess =
    user &&
    (!allowedRoles || allowedRoles.includes(user.role as Role)) &&
    (!allowedPlans || allowedPlans.includes(plan as Plan));

  return hasAccess ? <>{children}</> : <Navigate to="/unauthorized" />;
};

export default ProtectedRouteByPlanAndRole;
