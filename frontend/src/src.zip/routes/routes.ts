// @ts-check
import React from 'react';
import AdminAccessAudit from '@/pages/admin/AdminAccessAudit';
import ApiDashboardPage from '@/pages/ApiDashboardPage';
import SingleServicePage from '@/pages/SingleServicePage';

export enum ROUTES {
  ABOUT = "/about",
  ADMINANALYTICSPANEL = "/adminanalyticspanel",
  ADMINPANEL = "/adminpanel",
  BIEN = "/bien",
  BOURSELIVRE = "/bourselivre",
  COMMUNICATIONPANEL = "/communicationpanel",
  CONTACTENTERPRISE = "/contactenterprise",
  CONTACT = "/contact",
  CREATION_STORIES = "/creation.stories",
  CREATION = "/creation",
  DASHBOARD = "/dashboard",
  DASHBOARDIA = "/dashboardia",
  HOME = "/",
  INDEX = "/",
  LOGIN = "/login",
  MATCHING = "/matching",
  MATCHINGRESULTSIA = "/matchingresultsia",
  MATCH = "/match",
  NOTFOUND = "/notfound",
  OUTILS = "/outils",
  PAIEMENTPRO = "/paiementpro",
  PREDICTIONDASHBOARD = "/predictiondashboard",
  SERVICES = "/services",
  SERVICE_DETAIL = "/services/:id",
  STRATEGICRECOPANEL = "/strategicrecopanel",
  TICKET = "/ticket",
  UPGRADE = "/upgrade",
  USERINTERACTIONIACENTER = "/userinteractioniacenter",
  USERSTATSIADASHBOARD = "/userstatsiadashboard",
  ADMIN_AUDIT_ACCESS = "/admin/audit-access",
  ADMIN_API_DASHBOARD = "/admin/api-dashboard",
}

export type Role = "public" | "user" | "admin";

export interface RouteMeta {
  label: string;
  path: ROUTES | string;
  roles: Role[];
  component?: React.FC;
  plan?: "free" | "pro" | "enterprise";
}

export const ROUTES_CONFIG: RouteMeta[] = [
  { label: "About", path: ROUTES.ABOUT, roles: ["public"] },
  { label: "Admin Analytics Panel", path: ROUTES.ADMINANALYTICSPANEL, roles: ["admin"] },
  { label: "Admin Panel", path: ROUTES.ADMINPANEL, roles: ["admin"] },
  { label: "Bien", path: ROUTES.BIEN, roles: [] },
  { label: "Bourse Livre", path: ROUTES.BOURSELIVRE, roles: [] },
  { label: "Communication Panel", path: ROUTES.COMMUNICATIONPANEL, roles: [] },
  { label: "Contact Enterprise", path: ROUTES.CONTACTENTERPRISE, roles: [] },
  { label: "Contact", path: ROUTES.CONTACT, roles: [] },
  { label: "Creation Stories", path: ROUTES.CREATION_STORIES, roles: [] },
  { label: "Creation", path: ROUTES.CREATION, roles: [] },
  { label: "Dashboard", path: ROUTES.DASHBOARD, roles: [] },
  { label: "Dashboard IA", path: ROUTES.DASHBOARDIA, roles: [] },
  { label: "Home", path: ROUTES.HOME, roles: ["public"] },
  { label: "Index", path: ROUTES.INDEX, roles: ["public"] },
  { label: "Login", path: ROUTES.LOGIN, roles: ["public"] },
  { label: "Matching", path: ROUTES.MATCHING, roles: [] },
  { label: "Matching Results IA", path: ROUTES.MATCHINGRESULTSIA, roles: [] },
  { label: "Match", path: ROUTES.MATCH, roles: [] },
  { label: "Not Found", path: ROUTES.NOTFOUND, roles: [] },
  { label: "Outils", path: ROUTES.OUTILS, roles: [] },
  { label: "Paiement Pro", path: ROUTES.PAIEMENTPRO, roles: [] },
  { label: "Prediction Dashboard", path: ROUTES.PREDICTIONDASHBOARD, roles: [] },
  { label: "Services", path: ROUTES.SERVICES, roles: [] },
  {
    label: "Détail d'un service",
    path: ROUTES.SERVICE_DETAIL,
    roles: ["public"],
    component: SingleServicePage,
    plan: "free",
  },
  { label: "Strategic Reco Panel", path: ROUTES.STRATEGICRECOPANEL, roles: [] },
  { label: "Ticket", path: ROUTES.TICKET, roles: [] },
  { label: "Upgrade", path: ROUTES.UPGRADE, roles: [] },
  { label: "User Interaction IACenter", path: ROUTES.USERINTERACTIONIACENTER, roles: [] },
  { label: "User Stats IADashboard", path: ROUTES.USERSTATSIADASHBOARD, roles: [] },
  {
    label: "Audit des accès",
    path: ROUTES.ADMIN_AUDIT_ACCESS,
    roles: ["admin"],
    component: AdminAccessAudit,
    plan: "enterprise",
  },
  {
    label: "API Dashboard",
    path: ROUTES.ADMIN_API_DASHBOARD,
    roles: ["admin"],
    component: ApiDashboardPage,
    plan: "enterprise",
  },
];
