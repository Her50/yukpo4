// src/hooks/useUser.ts
// @ts-check
import { jwtDecode } from 'jwt-decode';

export type Role = 'admin' | 'user' | 'client' | 'public';

export interface DecodedToken {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  exp: number;
  name?: string;
  photo?: string;
  picture?: string;
}

export interface User {
  id: string;
  email: string;
  role: Role;
  plan: 'free' | 'pro' | 'enterprise';
  isAdmin: boolean;
  isUser: boolean;
  name: string;
  photo: string;
}

export function useUser(): {
  user: User | null;
  login: (token: string) => void;
  logout: () => void;
} {
  const token = localStorage.getItem('token');

  let user: User | null = null;

  if (token) {
    try {
      const decoded = jwtDecode<DecodedToken>(token);

      if (decoded.exp * 1000 < Date.now()) {
        localStorage.removeItem('token');
      } else {
        user = {
          id: decoded.id,
          email: decoded.email,
          role: decoded.role,
          plan: decoded.plan,
          isAdmin: decoded.role === 'admin',
          isUser: decoded.role === 'user',
          name: decoded.name || '',
          photo: decoded.photo || decoded.picture || '',
        };
      }
    } catch (e) {
      console.error('❌ Erreur décodage JWT :', e);
      localStorage.removeItem('token');
    }
  }

  // ✅ Fallback admin testeur automatique en DEV
  if (!user && import.meta.env.DEV) {
    user = {
      id: 'dev-admin',
      email: 'admin@yukpo.local',
      role: 'admin',
      plan: 'enterprise',
      isAdmin: true,
      isUser: false,
      name: 'Admin Local',
      photo: '',
    };
    console.warn('🧪 Utilisateur admin local injecté pour développement');
  }

  return {
    user,
    login: (token: string) => {
      localStorage.setItem('token', token);
      window.location.reload();
    },
    logout: () => {
      localStorage.removeItem('token');
      window.location.href = '/login';
    },
  };
}
