import React from "react";

const ContactPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>ContactPage.stories</h2>
    </div>
  );
};

export default ContactPageStories;
