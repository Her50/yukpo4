import React from "react";

const LoginPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>LoginPage.stories</h2>
    </div>
  );
};

export default LoginPageStories;
