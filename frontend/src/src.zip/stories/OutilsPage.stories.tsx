import React from "react";

const OutilsPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>OutilsPage.stories</h2>
    </div>
  );
};

export default OutilsPageStories;
