import React from "react";

const PaiementProPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>PaiementProPage.stories</h2>
    </div>
  );
};

export default PaiementProPageStories;
