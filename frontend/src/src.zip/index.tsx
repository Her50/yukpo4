import React from "react";

const index: React.FC = () => {
  return (
    <div className="p-4">
      <h2>index</h2>
    </div>
  );
};

export default index;
