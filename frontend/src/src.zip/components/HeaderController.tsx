// 1. FICHIER : src/components/HeaderController.tsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";
import DesktopMenu from "@/components/DesktopMenu";
import MobileMenu from "@/components/MobileMenu";
import LangSwitcher from "@/components/LangSwitcher";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const HeaderController: React.FC = () => {
  const { user, logout } = useUser();
  const { plan } = useUserPlan();
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const active = stored || (prefersDark ? "dark" : "light");
    setTheme(active);
    document.documentElement.classList.toggle("dark", active === "dark");
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-white dark:bg-gray-900 shadow px-6 h-24 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <Link to={ROUTES.HOME} className="flex items-center gap-2">
          <img src={logo} alt="Yukpo" className="h-10 w-auto object-contain" />
        </Link>
        <DesktopMenu />
      </div>

      <div className="flex items-center gap-3">
        {user ? (
          <div className="hidden md:flex flex-col text-xs text-right text-gray-700 dark:text-gray-300 leading-tight">
            <span>Rôle: <strong>{user.role}</strong></span>
            <span>Plan: <strong>{plan}</strong></span>
            <button
              onClick={logout}
              className="text-red-600 hover:underline text-xs mt-1"
              title="Se déconnecter"
            >
              🚪 Déconnexion
            </button>
          </div>
        ) : (
          <div className="hidden md:flex gap-2">
            <Link to={ROUTES.LOGIN} className="text-sm text-primary hover:underline">
              Connexion
            </Link>
            <Link to={ROUTES.REGISTER} className="text-sm text-yellow-500 hover:underline">
              Inscription
            </Link>
          </div>
        )}

        <LangSwitcher />
        <MobileMenu />
        <button
          onClick={toggleTheme}
          title="Changer le thème"
          className="text-xl"
        >
          {theme === "dark" ? "☽" : "☀"}
        </button>
      </div>
    </header>
  );
};

export default HeaderController;

