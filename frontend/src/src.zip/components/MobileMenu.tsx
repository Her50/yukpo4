﻿// @ts-check
import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";
import { useTranslation } from "react-i18next";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const MobileMenu: React.FC = () => {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { user, logout } = useUser();
  const { plan } = useUserPlan();
  const { i18n, t } = useTranslation();

  const toggleMenu = () => setOpen((prev) => !prev);

  const handleLogout = () => {
    if (confirm("🔒 Voulez-vous vous déconnecter ?")) {
      logout();
      setOpen(false);
    }
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  const baseLinks = [
    { to: ROUTES.HOME, label: t("Accueil") },
    { to: ROUTES.SERVICES, label: t("Services") },
    { to: ROUTES.PLANS, label: t("Abonnement") },
    { to: ROUTES.CONTACT, label: t("Contact") },
    { to: ROUTES.ABOUT, label: t("À propos") },
  ];

  const extraLinks: { to: string; label: string }[] = [];

  if (user) {
    extraLinks.push({ to: ROUTES.ESPACE, label: t("Mon Espace") });

    if (user.role === "admin") {
      extraLinks.push({ to: ROUTES.DASHBOARD_ADMIN_AUDIT, label: t("Audit sécurité") });
    }

    if (["pro", "enterprise"].includes(plan)) {
      extraLinks.push({ to: ROUTES.DASHBOARD_MES_SERVICES, label: t("Mes Services") });
    }

    if (plan === "enterprise") {
      extraLinks.push({ to: ROUTES.DASHBOARD_STATS, label: t("Statistiques") });
      extraLinks.push({ to: ROUTES.DASHBOARD_API, label: t("API IA") });
    }
  }

  const allLinks = [...baseLinks, ...extraLinks];

  const uniqueLinks = allLinks.filter(
    (link, index, self) => index === self.findIndex((l) => l.to === link.to)
  );

  return (
    <div className="md:hidden relative z-50" ref={menuRef}>
      <button
        onClick={toggleMenu}
        className="p-2 text-primary text-2xl"
        aria-label="Ouvrir menu"
      >
        ☰
      </button>

      {open && (
        <div className="absolute top-14 right-0 bg-white w-64 rounded shadow-md p-4 text-sm">
          <nav className="flex flex-col gap-3">
            {uniqueLinks.map(({ to, label }) => (
              <Link key={to} to={to} onClick={toggleMenu}>
                {label}
              </Link>
            ))}

            {user && (
              <>
                <div className="text-gray-600 text-xs pt-2">
                  Rôle : <strong>{user.role}</strong>
                </div>
                <div className="text-gray-600 text-xs">
                  Plan : <strong>{plan}</strong>
                </div>
                <button
                  onClick={handleLogout}
                  className="text-red-600 hover:underline text-left mt-2"
                >
                  🚪 {t("Déconnexion")}
                </button>
              </>
            )}

            <select
              className="mt-3 border px-2 py-1 rounded bg-white"
              value={i18n.language}
              onChange={(e) => i18n.changeLanguage(e.target.value)}
            >
              <option value="fr">🇫🇷 Français</option>
              <option value="en">🇬🇧 English</option>
              <option value="pt">🇵🇹 Português</option>
              <option value="ar">🇸🇦 العربية</option>
              <option value="ff">🌍 Fula</option>
            </select>
          </nav>
        </div>
      )}
    </div>
  );
};

export default MobileMenu;
