﻿// @ts-check
import React from "react";
import { Link } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";

// ✨ Composant YukpoBrand (centralisé si besoin)
const YukpoBrand = () => (
  <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent font-bold">
    Yukpo
  </span>
);

const legalLinks = [
  { path: ROUTES.LEGAL_NOTICE, label: "Mentions légales" },
  { path: ROUTES.PRIVACY, label: "Confidentialité" },
  { path: ROUTES.COOKIES, label: "Cookies" },
  { path: ROUTES.ABOUT, label: "À propos" },
];

// ✅ Supprimer les doublons en fonction du `path`
const uniqueLinks = legalLinks.filter(
  (link, index, self) =>
    self.findIndex((l) => l.path === link.path) === index
);

const Footer: React.FC = () => (
  <footer className="w-full border-t px-4 py-6 text-sm bg-white dark:bg-gray-900 dark:text-gray-400 text-gray-600">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <p className="text-sm font-light">
        <YukpoBrand /> © 2025 — Tous droits réservés.
      </p>

      <nav className="flex flex-wrap gap-4 text-sm font-light">
        {uniqueLinks.map(({ path, label }) => (
          <Link key={path} to={path} className="hover:underline">
            {label}
          </Link>
        ))}
      </nav>
    </div>
  </footer>
);

export default Footer;
