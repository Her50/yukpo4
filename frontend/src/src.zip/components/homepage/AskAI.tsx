import React from "react";

const AskAI: React.FC = () => {
  return (
    <div className="p-4">
      <h2>AskAI</h2>
    </div>
  );
};

export default AskAI;
