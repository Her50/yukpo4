import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";

const DesktopMenu: React.FC = () => {
  const { user } = useUser();
  const { plan } = useUserPlan();
  const location = useLocation();
  const current = location.pathname;

  const baseLinks = [
    { path: ROUTES.HOME, label: "Accueil" },
    { path: ROUTES.SERVICES, label: "Services" },
    { path: ROUTES.PLANS, label: "Abonnement" },
    { path: ROUTES.CONTACT, label: "Contact" },
    { path: ROUTES.ABOUT, label: "À propos" },
  ];

  const extraLinks: { path: string; label: string }[] = [];

  if (user) {
    extraLinks.push({ path: ROUTES.ESPACE, label: "Mon Espace" });

    if (user.role === "admin") {
      extraLinks.push({ path: ROUTES.DASHBOARD_ADMIN_AUDIT, label: "Audit sécurité" });
    }

    if (["pro", "enterprise"].includes(plan)) {
      extraLinks.push({ path: ROUTES.DASHBOARD_MES_SERVICES, label: "Mes Services" });
    }

    if (plan === "enterprise") {
      extraLinks.push({ path: ROUTES.DASHBOARD_STATS, label: "Statistiques" });
      extraLinks.push({ path: ROUTES.DASHBOARD_API, label: "API IA" });
    }
  }

  const allLinks = [...baseLinks, ...extraLinks];

  const uniqueLinks = allLinks.filter(
    (link, index, self) => index === self.findIndex((l) => l.path === link.path)
  );

  return (
    <ul className="hidden md:flex items-center flex-wrap gap-4 text-sm md:text-base text-gray-800 font-medium">
      {uniqueLinks.map(({ path, label }) => (
        <li key={path}>
          <Link
            to={path}
            className={`hover:text-primary transition-colors ${
              current === path ? "text-primary underline underline-offset-4 font-bold" : ""
            }`}
          >
            {label}
          </Link>
        </li>
      ))}
    </ul>
  );
};

export default DesktopMenu;
