export { default as RecentViewed } from './RecentViewed';
