﻿import React from 'react';
import BusinessServiceCard from "@/components/cards/ServiceCard";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const Services = [
  { nom: 'Yukpomnang Immobilier', description: 'Publication de biens professionnels', prix: 15000 },
  { nom: 'Yukpomnang Transport', description: 'Réservation billets + hôtels partenaires', prix: 20000 },
];

function ServicesPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">📦 Nos services</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {Services.map((s, i) => (
          <BusinessServiceCard key={i} {...s} />
        ))}
      </div>

      {/* 🚀 CONTEXTUAL BUTTONS START */}
      <div className="mt-10 flex flex-wrap gap-4 justify-center">
        <a
          href={ROUTES.SERVICES}
          className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 transition"
        >
          Découvrir d'autres services
        </a>
        <a
          href={ROUTES.PLANS}
          className="px-4 py-2 bg-yellow-400 text-black rounded hover:bg-yellow-500 transition"
        >
          Voir les formules
        </a>
        <a
          href={ROUTES.CONTACT}
          className="px-4 py-2 bg-gray-100 border rounded hover:bg-gray-200 transition"
        >
          Contacter l'équipe Yukpomnang
        </a>
      </div>
      {/* 🚀 CONTEXTUAL BUTTONS END */}
    </div>
  );
}

export default ServicesPage;
