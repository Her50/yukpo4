﻿// @ts-check
import React from "react";
import ResponsiveContainer from "@/components/layout/ResponsiveContainer";
import { MesServicesList } from "@/components/dashboard/MesServicesList";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const MesServicesPage: React.FC = () => {
  return (
    <ResponsiveContainer className="py-8">
      <h2 className="text-2xl font-bold mb-6">📦 Mes services</h2>

      <MesServicesList />

      {/* 🚀 CONTEXTUAL BUTTONS */}
      <div className="mt-8 flex flex-wrap gap-4 justify-center text-sm">
        <a href={ROUTES.SERVICES} className="text-blue-600 hover:underline">
          Découvrir d'autres services
        </a>
        <a href={ROUTES.PLANS} className="text-blue-600 hover:underline">
          Voir les formules
        </a>
        <a href={ROUTES.CONTACT} className="text-blue-600 hover:underline">
          Contacter l’équipe{" "}
          <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent font-semibold">
            Yukpo
          </span>
        </a>
      </div>
    </ResponsiveContainer>
  );
};

export default MesServicesPage;
