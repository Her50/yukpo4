// src/pages/PlansPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const plans = [
  {
    name: "Free",
    price: "0 FCFA",
    features: ["Accès de base", "IA limitée", "Support communautaire"],
    link: ROUTES.REGISTER
  },
  {
    name: "Pro",
    price: "15.000 FCFA/mois",
    features: ["Accès complet", "IA prédictive", "Assistance prioritaire"],
    link: ROUTES.PAIEMENTPRO
  },
  {
    name: "Enterprise",
    price: "50.000 FCFA/mois",
    features: ["Modules IA complets", "Reporting", "Support dédié"],
    link: ROUTES.PLAN_ENTERPRISE
  }
];

const PlansPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="py-16 text-center font-sans">
        <h2 className="text-3xl font-bold mb-10">💼 Choisissez votre plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((p, i) => (
            <div key={i} className="border rounded-lg p-6 shadow-md bg-white dark:bg-gray-800">
              <h3 className="text-xl font-semibold mb-2">{p.name}</h3>
              <p className="text-lg font-bold mb-4 text-primary">{p.price}</p>
              <ul className="text-sm text-gray-700 dark:text-gray-200 mb-4">
                {p.features.map((f, j) => (
                  <li key={j} className="mb-1">✔️ {f}</li>
                ))}
              </ul>
              <a href={p.link} className="btn-primary inline-block">Souscrire</a>
            </div>
          ))}
        </div>
      </section>
    </AppLayout>
  );
};

export default PlansPage;
