// src/pages/ContactPage.tsx
import React, { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import ResponsiveContainer from "@/components/layout/ResponsiveContainer";

const ContactPage: React.FC = () => {
  const [form, setForm] = useState({ nom: "", email: "", message: "" });
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: any) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 700)); // simulate API
    setSuccess(true);
    setLoading(false);
  };

  return (
    <AppLayout>
      <ResponsiveContainer className="py-16 max-w-xl font-sans">
        <h1 className="text-3xl font-bold mb-6 text-primary text-center">📬 Contactez-nous</h1>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <input name="nom" value={form.nom} onChange={handleChange} required placeholder="Votre nom" className="input" />
          <input type="email" name="email" value={form.email} onChange={handleChange} required placeholder="Votre email" className="input" />
          <textarea name="message" value={form.message} onChange={handleChange} required rows={5} placeholder="Votre message..." className="input" />
          <button type="submit" className="btn-primary w-full">{loading ? "Envoi..." : "Envoyer"}</button>
          {success && <p className="text-green-600 text-sm">✅ Message envoyé avec succès !</p>}
        </form>
      </ResponsiveContainer>
    </AppLayout>
  );
};

export default ContactPage;
