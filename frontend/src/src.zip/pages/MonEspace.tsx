// src/pages/MonEspace.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";

const MonEspace: React.FC = () => {
  const recent = [
    { id: 1, label: "Publication d’un bien à Douala", date: "2025-05-01" },
    { id: 2, label: "Génération IA de fiche descriptive", date: "2025-05-03" },
    { id: 3, label: "Connexion réussie", date: "2025-05-05" },
  ];

  return (
    <AppLayout>
      <section className="py-16 font-sans">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-900 dark:text-white">
          🧭 Mon Espace Personnel
        </h1>

        <div className="max-w-3xl mx-auto bg-white dark:bg-gray-900 border rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4 dark:text-white">Dernières interactions</h2>
          <ul className="space-y-3">
            {recent.map((item) => (
              <li key={item.id} className="border-l-4 border-primary pl-4 py-2 dark:text-gray-200">
                <p className="font-medium">{item.label}</p>
                <p className="text-xs text-gray-500">{item.date}</p>
              </li>
            ))}
          </ul>

          <div className="mt-8 text-center">
            <button className="px-6 py-3 bg-yellow-400 hover:bg-yellow-500 text-black font-medium rounded">
              ⚡ Lancer une action IA
            </button>
          </div>
        </div>
      </section>
    </AppLayout>
  );
};

export default MonEspace;
