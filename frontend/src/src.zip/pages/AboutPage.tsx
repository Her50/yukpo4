// src/pages/AboutPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";

const AboutPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="pt-16 pb-12 max-w-3xl mx-auto font-sans">
        <h1 className="text-3xl font-bold mb-6 text-primary">À propos de Yukpomnang</h1>
        <p className="mb-4 text-gray-700 dark:text-gray-200">
          Yukpomnang est une plateforme intelligente d’intermédiation entre besoins et solutions.
          Propulsée par l’IA, elle agit en temps réel pour vous connecter au bon service.
        </p>
        <p className="mb-4 text-gray-700 dark:text-gray-200">
          Notre technologie repose sur la reconnaissance vocale, l’automatisation des tâches et la
          personnalisation des services. Accessible en multilingue, Yukpomnang s’adapte à vos besoins
          locaux et professionnels.
        </p>
        <p className="text-gray-700 dark:text-gray-200">Essayez-nous dès maintenant !</p>
      </section>
    </AppLayout>
  );
};

export default AboutPage;
