import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';


type Props = {
  title: string;
  tag: string;
  price: number;
  features: string[];
};

const CatalogueCard: React.FC<Props> = ({ title, tag, price, features }) => {
  return (
    <div className="border p-4 rounded shadow-sm hover:shadow-md transition">
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="text-sm text-gray-500 mb-1">{tag}</p>
      <p className="text-md text-orange-600 font-semibold mb-2">{price} €</p>
      <ul className="list-disc list-inside text-sm text-gray-600">
        {features.map((feat, i) => (
          <li key={i}>{feat}</li>
        ))}
      </ul>
    </div>
  );
};

export default CatalogueCard;