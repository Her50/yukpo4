export { default as ServiceTemplateCard } from './ServiceTemplateCard';
