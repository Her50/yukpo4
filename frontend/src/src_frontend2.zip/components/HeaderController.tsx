// src/components/HeaderController.tsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";
import DesktopMenu from "@/components/DesktopMenu";
import MobileMenu from "@/components/MobileMenu";
import LangSwitcher from "@/components/LangSwitcher";
import { useUser } from "@/hooks/useUser";
import { useUserPlan } from "@/hooks/useUserPlan";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const HeaderController: React.FC = () => {
  const { user, logout } = useUser();
  const { plan } = useUserPlan();
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const active = stored || (prefersDark ? "dark" : "light");
    setTheme(active);
    document.documentElement.classList.toggle("dark", active === "dark");
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-white dark:bg-gray-900 shadow-sm border-b dark:border-gray-700">
      <div className="max-w-screen-2xl mx-auto px-6 h-24 flex items-center justify-between">
        {/* ✅ Bloc 1 : logo */}
        <div className="flex items-center gap-4 min-w-[120px]">
          <Link to={ROUTES.HOME} className="flex items-center gap-2">
            <img src={logo} alt="Yukpo" className="h-10 w-auto object-contain" />
          </Link>
        </div>

        {/* ✅ Bloc 2 : menu principal */}
        <div className="flex-1 flex justify-center gap-6 text-sm font-medium text-gray-700 dark:text-gray-200">
          <Link to="/recherche-besoin" className="hover:text-primary">
            💡 Trouver une solution
          </Link>
          <Link to="/creation-smart-service" className="hover:text-primary">
            ✍️ Publier un service
          </Link>
          <Link to="/ia-hub" className="hover:text-primary">
            🤖 IA Yukpo
          </Link>
        </div>

        {/* ✅ Bloc 3 : langue, rôle, logout */}
        <div className="hidden md:flex items-center gap-4 min-w-[240px] justify-end text-sm text-gray-700 dark:text-gray-200">
          {!user?.id ? (
            <>
              <Link to={ROUTES.LOGIN} className="text-blue-600 hover:underline">
                Connexion
              </Link>
              <Link to={ROUTES.REGISTER} className="text-yellow-600 hover:underline">
                Inscription
              </Link>
            </>
          ) : (
            <div className="flex flex-col text-xs text-right leading-tight">
              <span>Rôle : <strong>{user.role}</strong></span>
              <span>Plan : <strong>{plan}</strong></span>
              <button
                onClick={logout}
                className="text-red-600 hover:underline mt-1"
                title="Se déconnecter"
              >
                🚪 Déconnexion
              </button>
            </div>
          )}
          <LangSwitcher />
          <button
            onClick={toggleTheme}
            title="Changer le thème"
            className="text-xl hover:text-yellow-500"
          >
            {theme === "dark" ? "☽" : "☀"}
          </button>
        </div>

        {/* ✅ Bloc 4 : menu mobile toujours visible */}
        <div className="md:hidden">
          <MobileMenu />
        </div>
      </div>
    </header>
  );
};

export default HeaderController;
