// ✅ FICHIER 4 : frontend/src/components/dashboard/UrgentAlertPanel.tsx

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/buttons';

const UrgentAlertPanel: React.FC = () => {
  const [urgence, setUrgence] = useState<any | null>(null);

  useEffect(() => {
    // TODO: remplacer par WebSocket ou polling intelligent
    const fetchUrgence = async () => {
      const res = await axios.get('/api/urgence/entrante');
      setUrgence(res.data);
    };
    fetchUrgence();
  }, []);

  const handleAccept = async () => {
    await axios.post('/api/urgence/repondre', {
      urgence_id: urgence.id,
      prestataire_id: 'me', // à remplacer dynamiquement
      accepte: true
    });
    alert("Demande acceptée !");
  };

  const handleDecline = async () => {
    await axios.post('/api/urgence/repondre', {
      urgence_id: urgence.id,
      prestataire_id: 'me',
      accepte: false
    });
    setUrgence(null);
  };

  if (!urgence) return null;

  return (
    <Card className="p-4 bg-red-50 dark:bg-red-900">
      <h2 className="text-xl font-bold">🚨 Demande urgente</h2>
      <p className="text-sm mt-2">{urgence.texte}</p>
      <div className="mt-4 flex gap-4">
        <Button onClick={handleAccept} variant="default">✅ Accepter</Button>
        <Button onClick={handleDecline} variant="destructive">❌ Refuser</Button>
      </div>
    </Card>
  );
};

export default UrgentAlertPanel;
