// @ts-check
import React from "react";
import { useUserPlan } from "@/hooks/useUserPlan";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const ProOnlyBanner: React.FC = () => {
  const { isPro, isEnterprise } = useUserPlan();

  if (isPro || isEnterprise) return null;

  return (
    <div className="bg-yellow-100 border border-yellow-300 text-yellow-800 px-6 py-4 rounded-md shadow-md my-6 max-w-4xl mx-auto text-center">
      <h3 className="text-lg font-semibold mb-2">
        🔒 Cette fonctionnalité est réservée aux abonnés Pro ou Entreprise.
      </h3>
      <p className="text-sm">
        Passez à un plan supérieur pour débloquer l'accès à cette section.
      </p>
      <Link
        to={ROUTES.PLANS}
        aria-label="Voir les plans d'abonnement"
        className="mt-3 inline-flex items-center gap-2 bg-yellow-500 text-white px-4 py-2 rounded-full hover:bg-yellow-600 transition"
      >
        Découvrir les offres <ArrowRight size={16} />
      </Link>
    </div>
  );
};

export default ProOnlyBanner;
