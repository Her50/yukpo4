// 📁 src/pages/ResultatsBesoin.tsx
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/buttons";
import AppLayout from "@/components/layout/AppLayout";
import { useUser } from "@/hooks/useUser";
import { useTranslation } from "react-i18next";

interface ResultItem {
  id: string;
  nom: string;
  description: string;
  prix: string;
  vendeur: string;
  ville: string;
  image_url: string;
  note: number;
  type: string; // "bien" ou "service"
  prestataire_id: string;
}

const ResultatsBesoin: React.FC = () => {
  const { state } = useLocation();
  const { resultats = [], type = "" }: { resultats: ResultItem[]; type: string } = state || {};
  const { user } = useUser();
  const plan = user?.plan || "free";
  const { t } = useTranslation();
  const navigate = useNavigate();

  const getLimit = () => {
    if (plan === "enterprise") return 5;
    if (plan === "pro") return 3;
    return 1;
  };

  const isBien = ["immobilier", "meuble", "voiture", "electromenager"].includes(type);
  const resultsToDisplay = resultats.slice(0, getLimit());

  const handleViewDetails = (id: string) => {
    navigate(`/services/${id}`);
  };

  const handleContact = (prestataireId: string) => {
    navigate(`/contact-prestataire/${prestataireId}`);
  };

  return (
    <AppLayout padding>
      <div className="max-w-5xl mx-auto py-10 px-4">
        <h1 className="text-3xl font-bold text-center mb-6">
          {t("matching.similar_results")}
        </h1>

        {resultsToDisplay.length === 0 ? (
          <p className="text-center text-gray-500">{t("matching.no_results")}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resultsToDisplay.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-5 flex flex-col md:flex-row gap-4">
                  <img
                    src={item.image_url}
                    alt={item.nom}
                    className="w-full md:w-32 h-32 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h2 className="font-semibold text-lg">{item.nom}</h2>
                    <p className="text-sm text-gray-600">{item.description}</p>
                    <p className="text-sm font-medium mt-2">💰 {item.prix}</p>
                    <p className="text-sm text-gray-500">🛍 {item.vendeur} – 📍 {item.ville}</p>
                    <p className="text-sm text-yellow-600 mt-1">⭐ {item.note}/5</p>

                    <div className="flex flex-wrap gap-3 mt-4">
                      <Button size="sm" onClick={() => handleViewDetails(item.id)}>
                        🔍 Voir le détail
                      </Button>
                      {item.type === "service" ? (
                        plan === "free" ? (
                          <p className="text-xs text-red-600">
                            {t("matching.restricted_feature")}
                          </p>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleContact(item.prestataire_id)}
                          >
                            📞 Contacter le prestataire
                          </Button>
                        )
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(`/vitrine/${item.prestataire_id}`)}
                        >
                          🛍 Voir sa vitrine
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default ResultatsBesoin;
