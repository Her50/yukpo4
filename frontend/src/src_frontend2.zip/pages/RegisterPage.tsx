import React, { useState, useEffect } from 'react';
import ResponsiveContainer from '@/components/layout/ResponsiveContainer';

import { useNavigate } from "react-router-dom";
import { ROUTES } from "@/routes/AppRoutesRegistry";
import OAuthButton from "@/components/auth/OAuthButton";

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const passwordRegex = /^(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(form.password)) {
      setError("Mot de passe trop faible : 8 caractères, 1 majuscule, 1 chiffre minimum.");
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError("Les mots de passe ne correspondent pas.");
      return;
    }

    try {
      const res = await fetch("/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
        }),
      });

      if (res.ok) {
        navigate(ROUTES.CONFIRMATION);
      } else {
        const err = await res.json();
        setError(err.message || "Erreur d'inscription");
      }
    } catch (err) {
      setError("Échec de la connexion au serveur.");
    }
  };

  return (
    <main className="min-h-screen bg-yellow-50 pt-24">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-lg mx-auto">
          <h1 className="text-3xl font-bold mb-6 text-center text-gray-900">
            Créer un compte{" "}
            <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
              Yukpo
            </span>
          </h1>

          <p className="text-center text-gray-600 mb-4">
            Utilisez votre compte <strong>Google</strong> ou <strong>Facebook</strong> pour vous inscrire rapidement :
          </p>

          <div className="flex justify-center gap-4 mb-6">
            <OAuthButton provider="google" />
            <OAuthButton provider="facebook" />
          </div>

          <p className="text-center text-sm text-gray-500 mb-4">
            ou créez un compte manuellement
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              name="name"
              placeholder="Nom complet"
              value={form.name}
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded"
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Adresse email"
              value={form.email}
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded"
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Mot de passe"
              value={form.password}
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded"
              required
            />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirmer le mot de passe"
              value={form.confirmPassword}
              onChange={handleChange}
              className="w-full border px-4 py-2 rounded"
              required
            />

            <p className="text-xs text-gray-500 italic">
              Mot de passe requis : 8 caractères, 1 majuscule, 1 chiffre.
            </p>

            {error && (
              <p className="text-red-600 text-sm text-center">{error}</p>
            )}

            <button
              type="submit"
              className="w-full bg-yellow-500 text-black py-2 rounded font-semibold hover:bg-yellow-600"
            >
              Créer mon compte
            </button>
          </form>
        </div>
    </main>
  );
};

export default RegisterPage;