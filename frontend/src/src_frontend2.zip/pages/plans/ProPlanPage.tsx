
// ✅ src/pages/plans/ProPlanPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const ProPlanPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="py-16 text-center font-sans">
        <h1 className="text-3xl font-bold mb-6 text-yellow-500">🚀 Plan Pro Yukpo</h1>
        <p className="mb-4 text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
          Idéal pour les utilisateurs réguliers, le plan Pro vous ouvre l’accès à toutes les fonctions avancées de Yukpo.
        </p>
        <ul className="list-disc text-left max-w-md mx-auto mb-6 text-gray-700 dark:text-gray-200">
          <li>Accès complet à tous les services</li>
          <li>Recherche assistée + outils premium</li>
          <li>Support prioritaire</li>
        </ul>
        <a
          href={ROUTES.PAIEMENTPRO}
          className="btn-primary inline-block px-6 py-2 mt-4"
        >
          Souscrire au plan Pro
        </a>
      </section>
    </AppLayout>
  );
};

export default ProPlanPage;

