// src/pages/PlansPage.tsx
import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { ROUTES } from "@/routes/AppRoutesRegistry";

const plans = [
  {
    name: "Free",
    price: "0 FCFA",
    features: ["Accès de base", "Visibilité limitée", "Support communautaire"],
    link: ROUTES.REGISTER,
  },
  {
    name: "Pro",
    price: "15.000 FCFA/mois",
    features: ["Accès avancé", "Services intelligents", "Support prioritaire"],
    link: ROUTES.PAIEMENTPRO,
  },
  {
    name: "Enterprise",
    price: "Sur mesure",
    features: ["Services illimités", "Modules personnalisés", "Accompagnement dédié"],
    link: ROUTES.PLAN_ENTERPRISE,
  },
];

const PlansPage: React.FC = () => {
  return (
    <AppLayout>
      <section className="py-16 text-center font-sans bg-gradient-to-br from-yellow-50 via-white to-red-50">
        <h2 className="text-3xl font-bold mb-10 text-gray-900 dark:text-white">
          💼 Choisissez votre plan <span className="text-primary">Yukpo</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {plans.map((p, i) => (
            <div key={i} className="border rounded-lg p-6 shadow-md bg-white dark:bg-gray-800">
              <h3 className="text-xl font-semibold mb-2 text-gray-800 dark:text-white">
                {p.name}
              </h3>
              <p className="text-lg font-bold mb-4 text-primary">{p.price}</p>
              <ul className="text-sm text-gray-700 dark:text-gray-300 mb-4">
                {p.features.map((f, j) => (
                  <li key={j} className="mb-1">✔️ {f}</li>
                ))}
              </ul>
              <a
                href={p.link}
                className={`${
                  p.name === "Enterprise"
                    ? "bg-yellow-500 text-black hover:bg-yellow-600"
                    : "btn-primary"
                } inline-block px-4 py-2 rounded transition`}
              >
                {p.name === "Enterprise" ? "Demander un devis" : "Souscrire"}
              </a>
            </div>
          ))}
        </div>
      </section>
    </AppLayout>
  );
};

export default PlansPage;
