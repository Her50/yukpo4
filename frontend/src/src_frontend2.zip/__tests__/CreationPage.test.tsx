import React from "react";

const CreationPageTest: React.FC = () => {
  return (
    <div className="p-4">
      <h2>CreationPageTest</h2>
    </div>
  );
};

export default CreationPageTest;
