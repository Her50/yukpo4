import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// ✅ Import des fichiers de traduction
import en from './i18n/en.json';
import fr from './i18n/fr.json';
import ff from './i18n/ff.json';
import ar from './i18n/ar.json';
import pt from './i18n/pt.json';

// ✅ Définition des ressources
const resources = {
  en: { translation: en },
  fr: { translation: fr },
  ff: { translation: ff },
  ar: { translation: ar },
  pt: { translation: pt },
};

i18n
  .use(LanguageDetector) // 🌍 Détection auto navigateur ou localStorage
  .use(initReactI18next) // ⚛️ Intégration React
  .init({
    resources,
    fallbackLng: 'fr', // langue par défaut
    interpolation: {
      escapeValue: false, // désactive l’échappement (React gère)
    },
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'yukpo_lang', // 🔐 clé personnalisée
      caches: ['localStorage'],
    },
    react: {
      useSuspense: false, // ✅ permet d'éviter les erreurs initiales
    },
  });

export default i18n;
