import React from "react";

const RoleRestrictionDemoStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>RoleRestrictionDemo.stories</h2>
    </div>
  );
};

export default RoleRestrictionDemoStories;
