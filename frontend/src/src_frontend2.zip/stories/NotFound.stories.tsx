import React from "react";

const NotFoundStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>NotFound.stories</h2>
    </div>
  );
};

export default NotFoundStories;
