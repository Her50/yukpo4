import React from "react";

const MatchingPageStories: React.FC = () => {
  return (
    <div className="p-4">
      <h2>MatchingPage.stories</h2>
    </div>
  );
};

export default MatchingPageStories;
